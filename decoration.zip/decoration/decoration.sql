-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2019-04-30 10:57:30
-- 服务器版本： 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `decoration`
--

-- --------------------------------------------------------

--
-- 表的结构 `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `p_cate_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cart`
--

INSERT INTO `cart` (`id`, `p_cate_id`, `product_id`) VALUES
(15, 4, 5),
(14, 4, 2),
(16, 3, 6);

-- --------------------------------------------------------

--
-- 表的结构 `cate`
--

CREATE TABLE `cate` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0',
  `cate_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `cate_order` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `cate`
--

INSERT INTO `cate` (`id`, `pid`, `cate_name`, `cate_order`) VALUES
(1, 0, '灯具类', 1),
(2, 0, '家具类', 2),
(3, 1, '吊灯', 1),
(4, 2, '床柜', 1),
(5, 1, '主灯', 2),
(6, 2, '沙发', 3),
(7, 2, '桌椅', 4),
(8, 0, '家装设计师', 3),
(9, 8, '家装设计师', 1),
(10, 0, '建材类', 0),
(11, 10, '砖材', 0),
(12, 0, '五金类', 0),
(13, 0, '布艺类', 0),
(14, 12, '门锁', 0),
(15, 13, '窗帘', 0);

-- --------------------------------------------------------

--
-- 表的结构 `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `contact`
--

INSERT INTO `contact` (`id`, `user`, `email`, `comment`) VALUES
(1, 'sdrf', 'sdfgh', 'asdfghb'),
(2, 'asdf', 'asdf', 'asdfg'),
(3, 'asdf', 'sdf', 'sdf'),
(4, 'asdf', 'sdf', 'sdf'),
(5, 'sdf', 'asdfdg', 'fgdb'),
(6, 'sdfeerfgf', 'asdfdgff', 'fgdb'),
(7, 'sdfeerfgf', 'asdfdgff', 'fgdb'),
(10, 'zcv', 'sdxc', 'zxcvb'),
(11, 'asdfgh', 'sdfgh', 'sdf'),
(12, 'asdfgh', 'sdfgh', 'sdf'),
(13, 'sdfg', 'dfgh', 'szdfg'),
(14, 'sdfg', 'dfgh', 'szdfg'),
(15, 'sddf', 'sdfg', 'sdf'),
(16, 'asdfg', 'dfghfghn', 'cvb'),
(17, 'asdfg', 'dfghfghn', 'cvb'),
(18, 'asdfg', 'dfghfghn', 'cvb'),
(19, 'asdfg', 'dfghfghn', 'cvb'),
(20, 'sdfg', 'sdfg', 'xdcfgvb'),
(21, 'sdfg', 'sdfg', 'xdcfgvb'),
(22, 'sdf', 'dfgb', 'szdxcv'),
(24, 'sdf', 'dfgb', 'szdxcv'),
(25, 'sdf', 'dfgb', 'szdxcv'),
(26, 'sdf', 'dfgb', 'szdxcv'),
(28, 'sdf', 'df', 'sdf'),
(29, 'sdfgh', 'sdfgh', 'sdfg'),
(30, 'asdf', 'sdf', 'asdfg'),
(31, 'asdf', 'sdf', 'asdfg'),
(32, 'asdf', 'sdf', 'asdfg'),
(33, 'asdf', 'sdf', 'asdfg'),
(34, 'asdf', 'sdf', 'asdfg'),
(35, 'asdf', 'sdf', 'asdfg');

-- --------------------------------------------------------

--
-- 表的结构 `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `pid` int(11) DEFAULT NULL COMMENT '所属产品id',
  `url` varchar(255) DEFAULT NULL COMMENT '图片地址'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `image`
--

INSERT INTO `image` (`id`, `pid`, `url`) VALUES
(17, 2, '20190429\\44261f9c397b9b090ee2cb2b33d5e3c4.jpg'),
(11, 14, '20190429\\eff070d7708ef7d4dbe65353023b86fd.jpg'),
(12, 14, '20190429\\eb966b8c0dfb61e4f98fb912e9d67a5d.jpg'),
(13, 14, '20190429\\6ad4c065cd7260d7d916d4df0e174e1e.jpg'),
(14, 14, '20190429\\e983278350ec65850722bb037ff454a3.jpg'),
(15, 14, '20190429\\e0c3349dc45ff0fb61a4b33c077e946e.jpg'),
(16, 2, '20190429\\71e24a49bf2b57524749873361cea435.jpg'),
(18, 2, '20190429\\a3105185356e693fd8ca4c0a468d26c7.jpg'),
(19, 2, '20190429\\10554f846fbec221ea27de9e45134514.jpg'),
(20, 2, '20190429\\d0de2677377a0e76218996efd454ef91.jpg'),
(21, 1, '20190430\\2e4cf93bac85bf3c1624bbdc72e61f2a.jpg'),
(22, 1, '20190430\\6d1bfdae89087bac5da59f1088ffb57b.jpg'),
(23, 1, '20190430\\af81d52183042a8be06128cd4a6b9fc5.jpg'),
(24, 1, '20190430\\2bdae8f1eecb515b0fd267fe3d0b58c0.jpg'),
(25, 1, '20190430\\2afc64d77a3576e4dc09d6f6ef4554eb.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `p_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `p_cate_id` int(11) NOT NULL DEFAULT '0',
  `p_price` int(11) DEFAULT NULL,
  `p_brief` text CHARACTER SET utf8,
  `p_detail` text CHARACTER SET utf8,
  `p_img` varchar(500) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `product`
--

INSERT INTO `product` (`id`, `p_name`, `p_cate_id`, `p_price`, `p_brief`, `p_detail`, `p_img`) VALUES
(1, '北欧灯具ins简约现代创意卧室LED吸顶灯', 3, 120, '主要材质：铁', '<p>北欧灯具ins简约现代原木艺几何马卡龙书房少女创意卧室LED吸顶灯</p>', '20190429\\e21d406fd452c6d1f52bc617b61b2643.jpg'),
(2, '全屋定制电视柜整体家装衣柜定做卧室衣柜欧式衣帽间柜子家具定制', 4, 150, '全屋定制电视柜整体家装衣柜定做卧室衣柜欧式衣帽间柜子家具定制', '<p style=\"text-align: center; \">全屋定制电视柜整体家装衣柜定做卧室衣柜欧式衣帽间柜子家具定制</p>', '20190429\\d9f124c59939482d2505e87043924913.jpg'),
(5, '全屋定制电视柜整体家装衣柜定做卧室衣柜欧式衣帽间柜子家具定制', 4, 222, '全屋定制电视柜整体家装衣柜定做卧室衣柜欧式衣帽间柜子家具定制', '<p>全屋定制电视柜整体家装衣柜定做卧室衣柜欧式衣帽间柜子家具定制</p>', '20190429\\657ddeae6fcc8166a8212858c82f09c6.jpg'),
(8, '北欧灯具ins简约现代创意卧室LED吸顶灯', 3, 150, '北欧灯具ins简约现代创意卧室LED吸顶灯', '<p style=\"text-align: center;\">北欧灯具ins简约现代创意卧室LED吸顶灯</p>', '20190429\\279c7d46270d2744069f0a3820c78492.jpg'),
(9, '北欧灯具ins简约现代创意卧室LED吸顶灯', 3, 140, '北欧灯具ins简约现代创意卧室LED吸顶灯', '<p style=\"text-align: center;\">北欧灯具ins简约现代创意卧室LED吸顶灯</p>', '20190429\\5ce6cff93f14a9f754423a233fad44c8.jpg'),
(10, '简约现代创意个性马卡龙创意北欧灯具', 3, 220, '简约现代创意个性马卡龙创意北欧灯具', '<p style=\"text-align: center;\">简约现代创意个性马卡龙创意北欧灯具</p>', '20190429\\ac220bd0ca5358d51b7b73f1d191adea.jpg'),
(11, '设计师一', 8, 0, '设计师一设计师一设计师一设计师一设计师一设计师一设计师一', '<p>设计师一设计师一设计师一设计师一设计师一设计师一设计师一</p>', '20190429\\2635da1f680fef721b351d743d85ffea.jpg'),
(12, '设计师二', 8, 0, '设计师二设计师二设计师二', '<p>设计师二设计师二设计师二设计师二设计师二</p>', '20190429\\c3d2e16b2a2dfd7519bb196d0ab97730.jpg'),
(13, '设计师三', 8, 0, '设计师三设计师三设计师三', '<p>设计师三设计师三设计师三设计师三设计师三设计师三</p>', '20190429\\97e225d622d2dd7e2debf697a21e9929.jpg'),
(14, '北欧小户型布艺软靠多功能储物婚床', 4, 160, '简约现代1.8米主卧双人床1.5m北欧小户型布艺软靠多功能储物婚床', '<p style=\"text-align: center;\">简约现代1.8米主卧双人床1.5m北欧小户型布艺软靠多功能储物婚床</p>', '20190429\\f859b5a1186aeedfe917e94d310e7e1b.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `slide`
--

CREATE TABLE `slide` (
  `id` int(11) NOT NULL,
  `url` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `system`
--

CREATE TABLE `system` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `desc` varchar(25) DEFAULT NULL,
  `is_close` tinyint(2) DEFAULT NULL,
  `is_update` tinyint(2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `system`
--

INSERT INTO `system` (`id`, `title`, `keywords`, `desc`, `is_close`, `is_update`) VALUES
(1, '装饰品站点', '装饰品', '这是我的装饰品展示网站', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `is_admin` int(2) DEFAULT '0' COMMENT '是否是管理员 1是0否',
  `email` varchar(15) DEFAULT NULL,
  `mobile` varchar(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `is_admin`, `email`, `mobile`, `status`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1, 'admin@qq.com', '15145612351', 1),
(2, 'kong', '153ddfb15ae1e37b7cf004b201c3e3fd', 0, 'kong@qq.com', '15100115633', 1),
(3, 'aaa', '47bce5c74f589f4867dbd57e9ca9f808', 0, 'aaa@qq.com', '15100114561', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cate`
--
ALTER TABLE `cate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system`
--
ALTER TABLE `system`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- 使用表AUTO_INCREMENT `cate`
--
ALTER TABLE `cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- 使用表AUTO_INCREMENT `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- 使用表AUTO_INCREMENT `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- 使用表AUTO_INCREMENT `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- 使用表AUTO_INCREMENT `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `system`
--
ALTER TABLE `system`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
