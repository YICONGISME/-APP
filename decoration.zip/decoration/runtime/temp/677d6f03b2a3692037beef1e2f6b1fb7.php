<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:78:"G:\xampp\htdocs\decoration\public/../application/index\view\index\contact.html";i:1556538935;s:76:"G:\xampp\htdocs\decoration\public/../application/index\view\index\menu1.html";i:1556538999;s:78:"G:\xampp\htdocs\decoration\public/../application/index\view\public\header.html";i:1556527693;s:79:"G:\xampp\htdocs\decoration\public/../application/index\view\public\base_js.html";i:1556454279;s:78:"G:\xampp\htdocs\decoration\public/../application/index\view\public\footer.html";i:1555989510;}*/ ?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<!-- Latest Bootstrap min CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap.min.css" type="text/css">
	<!-- Dropdownhover CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap-dropdownhover.min.css" type="text/css">
	<!-- latest fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/font/css/font-awesome.min.css" type="text/css">
	<!-- simple line fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/simple-line-icon/css/simple-line-icons.css" type="text/css">
	<!-- stroke-gap-icons -->
	<link rel="stylesheet" href="__STATIC__/assets/stroke-gap-icons/stroke-gap-icons.css" type="text/css">
	<!-- Animate CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/animate.min.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/style.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/jcarousel.connected-carousels.css" type="text/css">
	<!--  baguetteBox -->
	<link rel="stylesheet" href="__STATIC__/assets/css/baguetteBox.css">
	<!-- Owl Carousel __STATIC__/assets -->
	<link href="__STATIC__/assets/owl-carousel/owl.carousel.css" rel="stylesheet">
	<link href="__STATIC__/assets/owl-carousel/owl.theme.css" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
</head>

<body>
<!--  Preloader  -->
<div id="preloader">
	<div id="loading">
	</div>
</div>
<header>
	<!--  top-header  -->
	<div class="top-header">
		<div class="container">

			<div class="col-md-6">
				<div class="top-header-left">
					<ul>
						<li>
							<i class="icon-location-pin icons" aria-hidden="true"></i>
							<a href="<?php echo url('index/index'); ?>">Hello 你好！</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-md-6">
				<div class="top-header-right">
					<ul>
						<?php if(\think\Session::get('user_id')): ?>
				        <li><a href="#"><?php echo \think\Session::get('user_id'); ?></a></li>
				        <?php else: ?>
				        <li><a href="<?php echo url('user/login'); ?>">登陆</a></li>
				        <li><a href="<?php echo url('user/register'); ?>">注册</a></li>
				        <?php endif; ?>
						<li>
							<div class="dropdown">
								<a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
									<i class="icon-settings icons" aria-hidden="true"></i> 设置
								</a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo url('admin/index/index'); ?>">管理中心</a></li>
									<li><a href="<?php echo url('user/logout'); ?>">退出登陆</a></li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>

		<!--  /top-header  -->
	</div>

<section class="top-md-menu">
	<div class="container">
		<div class="col-sm-3">
			<div class="logo">
				<h6><img src="__STATIC__/assets/images/logo.png" alt="logo" /></h6>
			</div>
		</div>
		<div class="col-sm-8">
			<!-- Search box Start -->
			<form action="<?php echo url('index/grid'); ?>" method="get" >
				<div class="well carousel-search hidden-phone">
					
					<div class="search">
						<input type="text" placeholder="搜索产品" name="keywords" style="padding-left: 50px;width: 84%;" />
					</div>
					<div class="btn-group">
						<button type="submit" onclick="search()" id="btnSearch" class="btn btn-primary" ><i class="fa fa-search" aria-hidden="true"></i></button>
					</div>
				</div>
			</form>
			<!-- Search box End -->
		</div>

		<div class="main-menu">
			<!--  nav  -->
			<nav class="navbar navbar-inverse navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" data-hover="dropdown" data-animations=" fadeInLeft fadeInUp fadeInRight">
					<ul class="nav navbar-nav">
						<li class="all-departments dropdown">
							<a href="<?php echo url('index/grid'); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span>产品分类</span> <i class="fa fa-bars" aria-hidden="true"></i> </a>
							<!-- <ul class="dropdown-menu dropdownhover-bottom all-open" role="menu"> -->
							<!-- 分类菜单列表 -->
							<ul class="dropdown-menu dropdownhover-bottom" role="menu">
							<?php if(is_array($cates) || $cates instanceof \think\Collection || $cates instanceof \think\Paginator): if( count($cates)==0 ) : echo "" ;else: foreach($cates as $key=>$vo): if($vo['cate_order'] != '3'): ?>
								<li class="dropdown">
									<a href="/decoration/public/index.php/index/index/grid?id=<?php echo $vo['id']; ?>"  value="<?php echo $vo['id']; ?>">
										<img src="__STATIC__/assets/images/menu-icon1.png" alt="menu-icon1" /> <?php echo $vo['cate_name']; ?> 
										<i class="fa fa-angle-right" aria-hidden="true"  style="margin-top: 5px;">
										</i>
									</a>
									
									<ul class="dropdown-menu right">
										<?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): if( count($vo['children'])==0 ) : echo "" ;else: foreach($vo['children'] as $key=>$vo1): ?>
										<li><a href="/decoration/public/index.php/index/index/grid?id=<?php echo $vo1['id']; ?>"><?php echo $vo1['cate_name']; ?></a>
										</li>
										<?php endforeach; endif; else: echo "" ;endif; ?>
									</ul>
									
								</li>
								<?php endif; endforeach; endif; else: echo "" ;endif; ?>	
							</ul>
						</li>
						<li><a href="<?php echo url('index/index'); ?>">首页</a></li>
						<li><a href="<?php echo url('index/grid'); ?>">产品网格</a></li>
						<li><a href="<?php echo url('index/contact'); ?>">联系我们</a></li>
					</ul>
					<!-- /.navbar-collapse -->
				</div>
			</nav>
			<!-- /nav end -->
		</div>
	</div>
</section>
<script src="__STATIC__/assets/js/jquery-3.3.1.min.js"></script>
<script src="__STATIC__/admin/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/admin/js/x-admin.js"></script>
<script src="__STATIC__/admin/js/jquery.min.js"></script>
<script src="__STATIC__/admin/js/x-layui.js"></script>

<!--  -->

	 <section class="shopping-cart">
            <!-- .shopping-cart -->
            <div class="container">
				<div class="row">
				<div class="col-md-6 contact-info">   
                  <div class="contact-form">
                     <form  id="contactform" class="comment-form">
							<div class="row">
								 <div class="col-md-12">
                           <!-- <input type="hidden" name="" value="<?php echo \think\Session::get('user_info.id'); ?>" > -->
								 <div class="contact-bg">                 
									<h2>联系我们</h2>
									<p>您可以留下您的邮箱，稍后我们会联系您.</p>
								</div> 
								</div>
								  <div class="col-md-6">
                              <div class="lable">Name <span>*</span></div>
                              <p class="comment-form-author"><input id="user" name="user" value="" size="30" type="text"></p>
                           </div>
                           <div class="col-md-6">
                              <div class="lable">Email <span>*</span></div>
                              <p class="comment-form-email"><input id="email" name="email" value="" size="30" type="text"></p>
                           </div>
                           <div class="col-md-12">
                              <div class="lable">Comments <span>*</span></div>
                              <p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="8" placeholder="Comment" aria-required="true"></textarea></p>
                           </div>
                           <div class="col-md-12">
                              <p class="form-submit"><input name="submit" id="submit" class="btn btn-secondary" value="send messages" type="submit">  </p> 
                           </div>                      
							 </div>                              
                        </form>
                     <p class="text-success" id="res"></p>

                     </div>
                  </div>
					<div class="col-md-6 contact-info">
						<div class="map">
                       <!--  map  -->
                       <!-- The element that will contain our Google Map. This is used in both the Javascript and CSS above. -->
                      		 <div id="map"></div>
                       <!--  m/ap  -->
                       </div> 
						<div class="col-md-12">
                     	<div class="contact-bg">                 
                        	<h2>Contact Us</h2>
							<p>我们的基本信息.</p>
                        </div>
                     </div>
                     <div class="col-sm-3 col-md-6">
                     	<div class="contact-bg">                 
                        <h6>Office Address</h6>石家庄
                        </div>
                     </div>
                     <div class="col-sm-3 col-md-6">
                     	<div class="contact-bg">                      
                        <h6>Email Address </h6>info@website.com<br>www.website.com                       
                        </div>
                     </div>
                     <div class="col-sm-3 col-md-6">
                     	<div class="contact-bg">                       
                        <h6>Phone Number</h6>1 234 567 890<br>9 876 543 210                       
                        </div>
                     </div>
                     <div class="col-sm-3 col-md-6">
                     	<div class="contact-bg">                        
                        <h6>Time Hourss</h6>
							Monday to Friday: 10h:00 Am to 7h:00 Pm<br/>
							Saturday: 10h:00 Am to 4h:00 Pm<br/>
							Sunday: 12h:00 Am to 4h:00 Pm
                        </div>
                     </div>
                        
                        
                  </div>
				</div>
               
            </div>
            <!-- /.shopping-cart -->
         </section>
	<!-- newsletter -->
	
<script src="__STATIC__/assets/js/jquery-3.3.1.min.js"></script>
<script src="__STATIC__/admin/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/admin/js/x-admin.js"></script>
<script src="__STATIC__/admin/js/jquery.min.js"></script>
<script src="__STATIC__/admin/js/x-layui.js"></script>


   <script type="text/javascript">
      $(function(){
         $('#submit').on('click',function(){
            //获取当前的用户id和栏目id

            var user = $('#user').val();
            var email = $('#email').val();
            var comment = $('#comment').val();
            
            console.log(user);
         
               $.ajax({
                  type:'get',
                  url:"<?php echo url('index/index/comment'); ?>",
                  data:{
                     user:  user,
                     email: email,
                     comment: comment,
                  },
                  dateType:     'json',
                  success : function(data){

                     switch(data.status){
                        case 1:
                        // $('#res').attr('class','btn btn-danger')
                        $('#res').text(data.message)
                        break;
                        // alert(data.message);

                        case 0:
                        // $('#res').attr('class','btn btn-default')
                        $('#res').text(data.message)
                        break;
                        
                     }
                  }
                  error:function(jqXHR,textStatus,errorThrown)
                  {
                     console.log(jqXHR.responseText);
                     console.log(textStatus);

                     console.log(errorThrown);
                  }
               })
               return false;
         })
   })
   

</script>

<footer>
	<div class="container">
			<!-- copayright -->
			<div class="copayright">
				<div class="row text-center">
					
						Copyright &copy; 2019. All rights reserved.
				</div>
			</div>
			<!-- /copayright -->

		</div>
	</div>
</footer>
<p id="back-top">
	<a href="#top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>
</p>
<script src="__STATIC__/assets/js/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="__STATIC__/assets/js/bootstrap.min.js"></script>
<script src="__STATIC__/assets/js/bootstrap-dropdownhover.min.js"></script>
<!-- Plugin JavaScript -->
<script src="__STATIC__/assets/js/jquery.easing.min.js"></script>
<script src="__STATIC__/assets/js/wow.min.js"></script>
<!-- owl carousel -->
<script src="__STATIC__/assets/owl-carousel/owl.carousel.js"></script>
<!--  Custom Theme JavaScript  -->
<!-- <script src="__STATIC__/assets/js/custom.js"></script> -->
	<script type="text/javascript" src="__STATIC__/assets/js/jquery.jcarousel.min.js"></script>
	<script type="text/javascript" src="__STATIC__/assets/js/jcarousel.connected-carousels.js"></script>
	<script type="text/javascript" src="__STATIC__/assets/js/jquery.elevatezoom.js"></script>
	<script>
		$('.zoom_01').elevateZoom({
			zoomType: "inner",
			cursor: "crosshair",
			zoomWindowFadeIn: 500,
			zoomWindowFadeOut: 750
		});
	</script>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=3.0&ak=P39PpXRcSvYIugAGG4HKCiB3GVNncaKA"></script> 
<script type="text/javascript">
    // 百度地图API功能
    var map = new BMap.Map("map");
    map.centerAndZoom(new BMap.Point(114.522081844,38.0489583146), 15);
    // 初始化地图,设置中心点坐标和地图级别，缩放
	//添加地图类型控件
	map.addControl(new BMap.MapTypeControl({
		mapTypes:[
            BMAP_NORMAL_MAP,
            BMAP_HYBRID_MAP
        ]}));	  
	map.setCurrentCity("石家庄");          // 设置地图显示的城市 此项是必须设置的
	map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放

</script>
<script type="text/javascript">
	$(".dropdown-menu li a").on('click', function (){
  var selText = $(this).text();
  $(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class="caret"></span>');
});

$("#btnSearch").on('click', function (){
	// alert($('.btn-select').text()+", "+$('.btn-select2').text());
});
</script>

</body>

</html>

