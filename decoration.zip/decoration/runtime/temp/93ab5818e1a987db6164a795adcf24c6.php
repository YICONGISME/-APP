<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:87:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\index\menu.html";i:1555980547;s:90:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\public\header.html";i:1555910457;s:91:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\public\base_js.html";i:1555923686;}*/ ?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<!-- Latest Bootstrap min CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap.min.css" type="text/css">
	<!-- Dropdownhover CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap-dropdownhover.min.css" type="text/css">
	<!-- latest fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/font/css/font-awesome.min.css" type="text/css">
	<!-- simple line fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/simple-line-icon/css/simple-line-icons.css" type="text/css">
	<!-- stroke-gap-icons -->
	<link rel="stylesheet" href="__STATIC__/assets/stroke-gap-icons/stroke-gap-icons.css" type="text/css">
	<!-- Animate CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/animate.min.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/style.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/jcarousel.connected-carousels.css" type="text/css">
	<!--  baguetteBox -->
	<link rel="stylesheet" href="__STATIC__/assets/css/baguetteBox.css">
	<!-- Owl Carousel __STATIC__/assets -->
	<link href="__STATIC__/assets/owl-carousel/owl.carousel.css" rel="stylesheet">
	<link href="__STATIC__/assets/owl-carousel/owl.theme.css" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
</head>

<body>
<!--  Preloader  -->
<div id="preloader">
	<div id="loading">
	</div>
</div>
<header>
	<!--  top-header  -->
	<div class="top-header">
		<div class="container">

			<div class="col-md-6">
				<div class="top-header-left">
					<ul>
						<li>
							<i class="icon-location-pin icons" aria-hidden="true"></i>Hello 你好！
						</li>
					</ul>
				</div>
			</div>
			<div class="col-md-6">
				<div class="top-header-right">
					<ul>
						<li><i class="icon-note icons" aria-hidden="true"></i> 登录/注册</li>
						<li>
							<div class="dropdown">
								<a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
									<i class="icon-settings icons" aria-hidden="true"></i> 设置
								</a>
								<ul class="dropdown-menu">
									<li><a href="#">My Account</a></li>
									<li><a href="#">Change Password</a></li>
									<li><a href="#">Change Address</a></li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>

		<!--  /top-header  -->
	</div>

<section class="top-md-menu">
	<div class="container">
		<div class="col-sm-3">
			<div class="logo">
				<h6><img src="__STATIC__/assets/images/logo.png" alt="logo" /></h6>
			</div>
		</div>
		<div class="col-sm-8">
			<!-- Search box Start -->
			<form>
				<div class="well carousel-search hidden-phone">
					<div class="btn-group">
						<a class="btn dropdown-toggle btn-select" data-toggle="dropdown" href="#">所有分类 <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href="#">Item I</a></li>
							<li><a href="#">Item II</a></li>
							<li><a href="#">Item III</a></li>
							<li class="divider"></li>
							<li><a href="#">Other</a></li>
						</ul>
					</div>
					<div class="search">
						<input type="text" placeholder="Search Product" />
					</div>
					<div class="btn-group">
						<button type="button" id="btnSearch" class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i></button>
					</div>
				</div>
			</form>
			<!-- Search box End -->
		</div>

		<div class="main-menu">
			<!--  nav  -->
			<nav class="navbar navbar-inverse navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" data-hover="dropdown" data-animations=" fadeInLeft fadeInUp fadeInRight">
					<ul class="nav navbar-nav">
						<li class="all-departments dropdown">
							<a href="index.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span>产品分类</span> <i class="fa fa-bars" aria-hidden="true"></i> </a>
							<!-- <ul class="dropdown-menu dropdownhover-bottom all-open" role="menu"> -->
							<!-- 分类菜单列表 -->
							<ul class="dropdown-menu dropdownhover-bottom" role="menu">
							<?php if(is_array($cates) || $cates instanceof \think\Collection || $cates instanceof \think\Paginator): if( count($cates)==0 ) : echo "" ;else: foreach($cates as $key=>$vo): ?>
								<li class="dropdown">
									<a href="index.php" value="<?php echo $vo['id']; ?>"><img src="__STATIC__/assets/images/menu-icon1.png" alt="menu-icon1" /> <?php echo $vo['cate_name']; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
									<ul class="dropdown-menu right">
										<?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): if( count($vo['children'])==0 ) : echo "" ;else: foreach($vo['children'] as $key=>$vo1): ?>
										<li><a href="/decoration/public/index.php/index/index/grid?id=<?php echo $vo1['id']; ?>"><?php echo $vo1['cate_name']; ?></a>
										</li>
										<?php endforeach; endif; else: echo "" ;endif; ?>
									</ul>
								</li>
							<?php endforeach; endif; else: echo "" ;endif; ?>

								<!-- 三级下拉菜单 -->
								<li class="dropdown">
									<a href="#"><img src="__STATIC__/assets/images/menu-icon4.png" alt="menu-icon4" /> Fashion & Clothing <i class="fa fa-angle-right" aria-hidden="true"></i></a>
									<div class="dropdown-menu dropdownhover-bottom mega-menu" role="menu">
									<div class="col-sm-8 col-md-8">
										<ul>
											<li><strong>Women’s Fashion</strong></li>
											<li><a href="#">Flip-Flops</a></li>
											<li><a href="#">Fashion Scarves</a></li>
											<li><a href="#">Wallets</a></li>
											<li><a href="#">Evening Handbags</a></li>
											<li><a href="#">Wrist Watches</a></li>
										</ul>
										<ul>
											<li><strong>Women’s Accessories</strong></li>
											<li><a href="#">Flip-Flops</a></li>
											<li><a href="#">Fashion Scarves</a></li>
											<li><a href="#">Wallets</a></li>
											<li><a href="#">Evening Handbags</a></li>
											<li><a href="#">Wrist Watches</a></li>
										</ul>
										<ul>
											<li><strong>Men’s Fashion</strong></li>
											<li><a href="#">Flip-Flops</a></li>
											<li><a href="#">Fashion Scarves</a></li>
											<li><a href="#">Wallets</a></li>
											<li><a href="#">Evening Handbags</a></li>
											<li><a href="#">Wrist Watches</a></li>
										</ul>
										<ul>
											<li><strong>Men’s Accessories</strong></li>
											<li><a href="#">Flip-Flops</a></li>
											<li><a href="#">Fashion Scarves</a></li>
											<li><a href="#">Wallets</a></li>
											<li><a href="#">Evening Handbags</a></li>
											<li><a href="#">Wrist Watches</a></li>
										</ul>
									</div>
									</div>
								</li>
								
							</ul>
						</li>
						<li><a href="index.php">首页</a></li>
						<li><a href="list.php">产品列表</a></li>
						<li><a href="grid.php">产品网格</a></li>
						<li><a href="shop-detail.php">详情页</a></li>
						<li><a href="contact.php">联系我们</a></li>
					</ul>
					<!-- /.navbar-collapse -->
				</div>
			</nav>
			<!-- /nav end -->
		</div>
	</div>
</section>
<input type="hidden" id="id" value="<?php echo $cate_id; ?>">
<script src="__STATIC__/admin/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/admin/js/x-admin.js"></script>
<script src="__STATIC__/admin/js/jquery.min.js"></script>
<script src="__STATIC__/admin/js/x-layui.js"></script>
<script type="text/javascript">
    layui.use(['laypage'],function(){
        // $ = layui.jquery;
        laypage = layui.laypage;

        laypage.render({
            elem: 'pages'
            ,count:<?php echo $count; ?>
            ,limit:<?php echo $pageSize; ?>
            ,curr:<?php echo $page; ?>
            ,jump: function(obj, first){
            if(!first){
                searchs(obj.curr);
            }
          }
        });
    });

    function searchs(page){
        // 获取用户选中的标签的值
        var id = document.getElementById('id').value;
      
        var url = '/decoration/public/index.php/index/index/grid?rand='+Math.random();
        if(id){
            url = url + '&id='+id;
        }
        
        window.location.href = url +'&page='+page;
    }
</script>