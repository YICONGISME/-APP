<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:76:"G:\xampp\htdocs\decoration\public/../application/index\view\index\index.html";i:1556601509;s:75:"G:\xampp\htdocs\decoration\public/../application/index\view\index\menu.html";i:1556601880;s:78:"G:\xampp\htdocs\decoration\public/../application/index\view\public\header.html";i:1556527693;s:79:"G:\xampp\htdocs\decoration\public/../application/index\view\public\base_js.html";i:1556454279;s:78:"G:\xampp\htdocs\decoration\public/../application/index\view\public\footer.html";i:1555989510;}*/ ?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<!-- Latest Bootstrap min CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap.min.css" type="text/css">
	<!-- Dropdownhover CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap-dropdownhover.min.css" type="text/css">
	<!-- latest fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/font/css/font-awesome.min.css" type="text/css">
	<!-- simple line fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/simple-line-icon/css/simple-line-icons.css" type="text/css">
	<!-- stroke-gap-icons -->
	<link rel="stylesheet" href="__STATIC__/assets/stroke-gap-icons/stroke-gap-icons.css" type="text/css">
	<!-- Animate CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/animate.min.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/style.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/jcarousel.connected-carousels.css" type="text/css">
	<!--  baguetteBox -->
	<link rel="stylesheet" href="__STATIC__/assets/css/baguetteBox.css">
	<!-- Owl Carousel __STATIC__/assets -->
	<link href="__STATIC__/assets/owl-carousel/owl.carousel.css" rel="stylesheet">
	<link href="__STATIC__/assets/owl-carousel/owl.theme.css" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
</head>

<body>
<!--  Preloader  -->
<div id="preloader">
	<div id="loading">
	</div>
</div>
<header>
	<!--  top-header  -->
	<div class="top-header">
		<div class="container">

			<div class="col-md-6">
				<div class="top-header-left">
					<ul>
						<li>
							<i class="icon-location-pin icons" aria-hidden="true"></i>
							<a href="<?php echo url('index/index'); ?>">Hello 你好！</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-md-6">
				<div class="top-header-right">
					<ul>
						<?php if(\think\Session::get('user_id')): ?>
				        <li><a href="#"><?php echo \think\Session::get('user_id'); ?></a></li>
				        <?php else: ?>
				        <li><a href="<?php echo url('user/login'); ?>">登陆</a></li>
				        <li><a href="<?php echo url('user/register'); ?>">注册</a></li>
				        <?php endif; ?>
						<li>
							<div class="dropdown">
								<a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
									<i class="icon-settings icons" aria-hidden="true"></i> 设置
								</a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo url('admin/index/index'); ?>">管理中心</a></li>
									<li><a href="<?php echo url('user/logout'); ?>">退出登陆</a></li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>

		<!--  /top-header  -->
	</div>

<section class="top-md-menu">
	<div class="container">
		<div class="col-sm-3">
			<div class="logo">
				<h6><img src="__STATIC__/assets/images/logo.png" alt="logo" /></h6>
			</div>
		</div>
		<div class="col-sm-8">
			<!-- Search box Start -->
			<form action="<?php echo url('index/grid'); ?>" method="get" >
				<div class="well carousel-search hidden-phone">
					
					<div class="search">
						<input type="text" placeholder="搜索产品" name="keywords" style="padding-left: 50px;width: 84%;" />
					</div>
					<div class="btn-group">
						<button type="submit" onclick="search()" id="btnSearch" class="btn btn-primary" ><i class="fa fa-search" aria-hidden="true"></i></button>
					</div>
				</div>
			</form>
			<!-- Search box End -->
		</div>

		<div class="main-menu">
			<!--  nav  -->
			<nav class="navbar navbar-inverse navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" data-hover="dropdown" data-animations=" fadeInLeft fadeInUp fadeInRight">
					<ul class="nav navbar-nav">
						<li class="all-departments dropdown">
							<a href="<?php echo url('index/grid'); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span>产品分类</span> <i class="fa fa-bars" aria-hidden="true"></i> </a>
							<ul class="dropdown-menu dropdownhover-bottom all-open" role="menu">
							<!-- 分类菜单列表 -->
							<!-- <ul class="dropdown-menu dropdownhover-bottom" role="menu"> -->
							<?php if(is_array($cates) || $cates instanceof \think\Collection || $cates instanceof \think\Paginator): if( count($cates)==0 ) : echo "" ;else: foreach($cates as $key=>$vo): if($vo['cate_order'] != '3'): ?>
								<li class="dropdown">
									<a href="/decoration/public/index.php/index/index/grid?id=<?php echo $vo['id']; ?>"  value="<?php echo $vo['id']; ?>">
										<img src="__STATIC__/assets/images/menu-icon1.png" alt="menu-icon1" /> <?php echo $vo['cate_name']; ?> 
										<i class="fa fa-angle-right" aria-hidden="true"  style="margin-top: 5px;">
										</i>
									</a>
									
									<ul class="dropdown-menu right">
										<?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): if( count($vo['children'])==0 ) : echo "" ;else: foreach($vo['children'] as $key=>$vo1): ?>
										<li><a href="/decoration/public/index.php/index/index/grid?id=<?php echo $vo1['id']; ?>"><?php echo $vo1['cate_name']; ?></a>
										</li>
										<?php endforeach; endif; else: echo "" ;endif; ?>
									</ul>
									
								</li>
								<?php endif; endforeach; endif; else: echo "" ;endif; ?>	
							</ul>
						</li>
						<li><a href="<?php echo url('index/index'); ?>">首页</a></li>
						<li><a href="<?php echo url('index/grid'); ?>">全部产品</a></li>
						<li><a href="<?php echo url('index/contact'); ?>">联系我们</a></li>
					</ul>
					<!-- /.navbar-collapse -->
				</div>
			</nav>
			<!-- /nav end -->
		</div>
	</div>
</section>
<script src="__STATIC__/assets/js/jquery-3.3.1.min.js"></script>
<script src="__STATIC__/admin/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/admin/js/x-admin.js"></script>
<script src="__STATIC__/admin/js/jquery.min.js"></script>
<script src="__STATIC__/admin/js/x-layui.js"></script>

<!--  -->


<!-- header-outer -->
<section class="header-outer">
	<!-- header-slider -->
		<div class="header-slider">					
				<div id="home-slider" class="carousel slide carousel-fade" data-ride="carousel">
					<!-- .home-slider -->
					<div class="carousel-inner">
						<?php if(is_array($last_pro) || $last_pro instanceof \think\Collection || $last_pro instanceof \think\Paginator): $i = 0; $__LIST__ = $last_pro;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<div class="item <?php if($i==1){echo 'active'; }?>" style="background-image: url();  background-repeat: no-repeat; background-position: top;">
							<div class="container">		
								<div class="caption">
								<div class="caption-outer">
									<div class="col-xs-12 col-sm-12 col-md-4">							
										<img style="width:1100px;" src="/decoration/public/uploads/<?php echo $vo['p_img']; ?>">	
									</div>
									<div class="col-xs-12 col-sm-6 col-md-6">
										<h3><?php echo $vo['p_name']; ?></h3>
										<h2 class="animated wow slideInUp" data-wow-delay="0ms" data-wow-duration="1500ms"><?php echo $vo['p_name']; ?></h2>
										<h4>Only from ￥<?php echo $vo['p_price']; ?></h4>
										<p class="animated wow fadeInRight"><?php echo $vo['p_brief']; ?></p>
										<a data-scroll class="btn get-start animated fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms" href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>">BUY NOW</a>
									</div>
									<div class="col-xs-12 col-sm-6 col-md-2">												
										<div class="save-price animated wow slideInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
											<span class="save-text">From</span>
											<span class="saveprice-no"><sup>￥</sup><?php echo $vo['p_price']; ?></span>
										</div>
									</div>
								</div>
							</div>
							</div>
						</div>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						
					</div>
					<!-- indicators -->
					<ol class="carousel-indicators">
						<li data-target="#home-slider" data-slide-to="0" class="active"></li>
						<li data-target="#home-slider" data-slide-to="1"></li>
						<li data-target="#home-slider" data-slide-to="2"></li>
					</ol>
					<!-- /indicators -->
					<!-- /.home-slider -->
				</div>					
		</div>
		<!-- /header-slider end -->			
</section>
<!-- /header-outer -->
</header>
<!-- banner -->


<section class="banner">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-4 col-md-4">
				<!-- banner-img -->
				<a href="#" class="banner-img">
					<!-- banner-text -->
					<div class="banner-text" style="color:#ffffff!important;letter-spacing:0.6em">
						<h3>舒适家居</h3>
						<h2>物美价廉</h2>
						<span class="wk-price">好家居，质量保障</span>
					</div>
					<!-- /banner-text -->
				</a>
				<!-- /banner-img -->
			</div>
			<div class="col-xs-12 col-sm-4 col-md-4">
				<!-- banner-img -->
				<a href="#" class="banner-img banner-img2">
					<!-- banner-text -->
					<div class="banner-text" style="color:#ffffff!important">
						<h3>家装产品</h3>
						<h2>轻松搞定</h2>
						<span class="wk-price">一站式解决方案</span>
					</div>
					<!-- /banner-text -->
				</a>
				<!-- /banner-img -->
			</div>
			<div class="col-xs-12 col-sm-4 col-md-4">
				<!-- banner-img -->
				<a href="#" class="banner-img banner-img3">
					<!-- banner-text -->
					<div class="banner-text" style="color:#ffffff!important">
						<h3>创意设计</h3>
						<h2>与众不同</h2>
						<span class="wk-price">只有你想不到的</span>
					</div>
					<!-- /banner-text -->
				</a>
				<!-- /banner-img -->
			</div>
		</div>
	</div>
</section>
<!-- /banner -->


<!-- all-product -->
<section class="all-product">
	<div class="container">
		<div class="row">
			<!-- 分类标题及子分类 -->
			<?php if(is_array($cates) || $cates instanceof \think\Collection || $cates instanceof \think\Paginator): if( count($cates)==0 ) : echo "" ;else: foreach($cates as $key=>$vo): if($vo['cate_order'] != '3'): ?>

			<!-- title -->
			<div class="title">
				<h2>
					<?php echo $vo['cate_name']; ?>						
				</h2>
				<ul class="nav nav-tabs etabs">
					<?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): if( count($vo['children'])==0 ) : echo "" ;else: foreach($vo['children'] as $key=>$vo1): ?>
					<!-- 要实现此处，要使数据库中每个分类下的子分类排序都从1开始 -->
					<?php if($vo1['cate_order'] == '1'): ?>
						<li class="active" onchange=""><a data-toggle="tab" class="select" cid="<?php echo $vo1['id']; ?>" href="#<?php echo $vo1['cate_name']; ?>" ><?php echo $vo1['cate_name']; ?></a></li>
					<?php else: ?>	
						<li><a data-toggle="tab" href="#<?php echo $vo1['cate_name']; ?>" id="<?php echo $vo1['id']; ?>" name="<?php echo $vo1['id']; ?>"><?php echo $vo1['cate_name']; ?></a></li>
					<?php endif; endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			</div>

			<!-- /title -->
			<!-- electonics -->
			<div class="electonics">
				<!-- 分类左边轮播图 -->
				<div class="brd2 col-xs-12 col-sm-3 col-md-3">
				
				
					<div id="home-slider2" class="carousel slide carousel-fade" data-ride="carousel">
						<!-- .home-slider -->
						
						<div class="carousel-inner">	
							<?php if($vo['id'] == '1'): if(is_array($pro_list) || $pro_list instanceof \think\Collection || $pro_list instanceof \think\Paginator): $i = 0; $__LIST__ = $pro_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$voi): $mod = ($i % 2 );++$i;?>
							<div class="item <?php if($i==1){echo 'active'; }?>" style="width: 100%;">
								<a class="ads" href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>">
									<img src="/decoration/public/uploads/<?php echo $voi['p_img']; ?>" alt="add-banner"  width="100%;height100%;" />
								</a>
							</div>
							<?php endforeach; endif; else: echo "" ;endif; endif; ?>
						</div>
						
						<ol class="carousel-indicators">
							<li data-target="#home-slider2" data-slide-to="0" class="active"></li>
							<li data-target="#home-slider2" data-slide-to="1"></li>
						</ol>
					
							<!-- .home-slider -->
							<div class="carousel-inner">
							<?php if($vo['id'] == '2'): if(is_array($pro_list2) || $pro_list2 instanceof \think\Collection || $pro_list2 instanceof \think\Paginator): $i = 0; $__LIST__ = $pro_list2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$voi): $mod = ($i % 2 );++$i;?>	
								<div class="item <?php if($i==1){echo 'active'; }?>"  width="100%;height100%;">
									<a class="ads" href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>">
										<img src="/decoration/public/uploads/<?php echo $voi['p_img']; ?>" alt="add-banner"  width="100%;height100%;"/>
									</a>
								</div>
							<?php endforeach; endif; else: echo "" ;endif; endif; ?>
							</div>
							<!-- indicators -->
							<ol class="carousel-indicators">
								<li data-target="#home-slider2" data-slide-to="0" class="active"></li>
								<li data-target="#home-slider2" data-slide-to="1"></li>
							</ol>
							<!-- /indicators -->
							<!-- /.home-slider -->
						</div>
				</div>



				<div class="col-xs-12 col-sm-9 col-md-9">
					<div class="row">
						<!-- 每个标签下面的产品 -->
						<!-- tab-content -->

						<div class="tab-content">
							<!-- tab-pane -->
							

							<div id="<?php echo $vo1['cate_name']; ?>" class="tab-pane fade in active">									
								<div class="owl-demo-outer">
									<!-- #owl-demo -->
									<div id="owl-demo3" class="deals-wk2">
										<div class="item">
											<!-- 如果是分类一的子分类一 -->
											<?php if($vo['id'] == '1'): if(is_array($pro_list) || $pro_list instanceof \think\Collection || $pro_list instanceof \think\Paginator): $i = 0; $__LIST__ = $pro_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
											<div class="bdr col-xs-12 col-sm-12 col-md-6">
												<!-- e-product -->
												<div class="e-product">
													<div class="pro-img" style="padding:10px;">
														<img src="/decoration/public/uploads/<?php echo $vo['p_img']; ?>" alt="2">
														<div class="hover-icon">
															<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>"><i class="fa fa-search" aria-hidden="true"></i></a>
														</div>
													</div>
													<div class="pro-text-outer">
														<span></span>
														<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>">
															<h4> <?php echo $vo['p_name']; ?></h4>
														</a>
														<p class="wk-price">￥<?php echo $vo['p_price']; ?> </p>
														<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>" class="add-btn">Add to cart</a>
														<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>" class="add-btn2"><i class="icon-heart icons" aria-hidden="true"></i></a>
														<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>" class="add-btn2"><i class="icon-refresh icons"></i></a>
													</div>
												</div>
												<!-- /e-product -->
											</div>
											<?php endforeach; endif; else: echo "" ;endif; endif; ?>
											<!-- 如果是分类二 -->
											<?php if($vo['id'] == '2'): if(is_array($pro_list2) || $pro_list2 instanceof \think\Collection || $pro_list2 instanceof \think\Paginator): $i = 0; $__LIST__ = $pro_list2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
											<div class="bdr col-xs-12 col-sm-12 col-md-6">
												<!-- e-product -->
												<div class="e-product">
													<div class="pro-img" style="padding: 10px;">
														<img src="/decoration/public/uploads/<?php echo $vo['p_img']; ?>" alt="2">
														<div class="hover-icon">
															<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>"><i class="fa fa-search" aria-hidden="true"></i></a>
														</div>
													</div>
													<div class="pro-text-outer">
														<span></span>
														<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>">
															<h4> <?php echo $vo['p_name']; ?></h4>
														</a>
														<p class="wk-price">￥<?php echo $vo['p_price']; ?> </p>
														<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>" class="add-btn">Add to cart</a>
														<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>" class="add-btn2"><i class="icon-heart icons" aria-hidden="true"></i></a>
														<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>" class="add-btn2"><i class="icon-refresh icons"></i></a>
													</div>
												</div>
												<!-- /e-product -->
											</div>
											<?php endforeach; endif; else: echo "" ;endif; endif; ?>
											
										</div>
										
									</div>
								</div>
							</div>
							
							
						</div>
						<!-- /tab-content -->

					</div>
				</div>
			</div>
			<?php endif; endforeach; endif; else: echo "" ;endif; ?>
			<!-- /electonics -->

			<!-- Home-Garden-Kitchen -->
			<!-- half-banner -->
			<div class="title">
				<h2>
					家装设计师
				</h2>
			</div>
			<!-- /title -->
			<!-- BLOG -->
			<div class="home-blog">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="row">							
						<div class="owl-demo-outer">
							<!-- #owl-demo -->
							<div id="owl-demo2" class="deals-wk2">
								<!-- item -->
								<div class="item">
									<?php if(is_array($designer) || $designer instanceof \think\Collection || $designer instanceof \think\Paginator): $i = 0; $__LIST__ = $designer;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
									<div class="bdr col-xs-12 col-sm-6 col-md-4">
										<!-- blog-outer -->
									
										<div class="blog-outer">
											<div class="blog-img" style="height: 200px;">
												<img src="/decoration/public/uploads/<?php echo $vo['p_img']; ?>" style="width: 100%;height: 100%">
											</div>
											<div class="blog-text-outer">
													<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>">
													<h4><?php echo $vo['p_name']; ?></h4>
													</a>
												<p><span class="dt">March 20, 2017</span> by <span class="ath">Zcubedesign</span></p>
												<p class="content-text"><?php echo $vo['p_brief']; ?></p>
												<a href="/decoration/public/index.php/index/index/detail?id=<?php echo $vo['id']; ?>" class="add-btn">read more</a>

											</div>
										</div>
										<!-- /blog-outer -->
									</div>
									<?php endforeach; endif; else: echo "" ;endif; ?>
									
								</div>
								<!-- /item -->
							
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- /BLOG -->
		</div>
	</div>
</section>
<p id ="span"></p>
<!-- /all-product -->
<script src="__STATIC__/assets/js/jquery-3.3.1.min.js"></script>
<script src="__STATIC__/admin/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/admin/js/x-admin.js"></script>
<script src="__STATIC__/admin/js/jquery.min.js"></script>
<script src="__STATIC__/admin/js/x-layui.js"></script>


<script type="text/javascript">
	$(function(){
		$('.select').on('click',function(){
			
			// var cid = this.id;
			var cid = $(this).attr('cid');
			// var cateid = $('.select').text();
			// console.log(typeof this.id);  //3
			console.log(cid);  //3

			// var id = $('#<?php echo $vo1['id']; ?>').val();
			// console.log(id); 

			$.ajax({
				type:'get',
				url:'<?php echo url("index/index"); ?>',
				datatype:'json',
				// async:false,
				// content-type:'application/x-www-form-urlencoded',
				data:{cid:cid},
				success:function(data){
					if(data.code == 1)
					{
						
						// console.log(typeof data );
						// var res = eval("(" + data + ")");
						// console.log(typeof res );
						alert(data.msg);
					}else{
						// console.log(typeof data );
						// var data = $.parseJSON(data);
						// var res = eval("(" + data + ")");
						// console.log(typeof data);
						alert(data.msg);
					}
				}
				// 打印具体错误
			// 	error:function(jqXHR,textStatus,errorThrown)
			// 	{
			// 		console.log(jqXHR.responseText);
			// 		console.log(textStatus);

			// 		console.log(errorThrown);
			// 	}
			})
				return false;

			// $.get('<?php echo url("index/index"); ?>',{'cid':cid},function(res){
			// 		if(res.code == 1){
			// 			//出错之后更新验证码
			// 			alert('success');			
			// 		}else{
			// 			alert('error');
			// 		}
			// 	},'json',false);

		})
})
</script>


<footer>
	<div class="container">
			<!-- copayright -->
			<div class="copayright">
				<div class="row text-center">
					
						Copyright &copy; 2019. All rights reserved.
				</div>
			</div>
			<!-- /copayright -->

		</div>
	</div>
</footer>
<p id="back-top">
	<a href="#top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>
</p>
<script src="__STATIC__/assets/js/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="__STATIC__/assets/js/bootstrap.min.js"></script>
<script src="__STATIC__/assets/js/bootstrap-dropdownhover.min.js"></script>
<!-- Plugin JavaScript -->
<script src="__STATIC__/assets/js/jquery.easing.min.js"></script>
<script src="__STATIC__/assets/js/wow.min.js"></script>
<!-- owl carousel -->
<script src="__STATIC__/assets/owl-carousel/owl.carousel.js"></script>
<!--  Custom Theme JavaScript  -->
<!-- <script src="__STATIC__/assets/js/custom.js"></script> -->
	<script type="text/javascript" src="__STATIC__/assets/js/jquery.jcarousel.min.js"></script>
	<script type="text/javascript" src="__STATIC__/assets/js/jcarousel.connected-carousels.js"></script>
	<script type="text/javascript" src="__STATIC__/assets/js/jquery.elevatezoom.js"></script>
	<script>
		$('.zoom_01').elevateZoom({
			zoomType: "inner",
			cursor: "crosshair",
			zoomWindowFadeIn: 500,
			zoomWindowFadeOut: 750
		});
	</script>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=3.0&ak=P39PpXRcSvYIugAGG4HKCiB3GVNncaKA"></script> 
<script type="text/javascript">
    // 百度地图API功能
    var map = new BMap.Map("map");
    map.centerAndZoom(new BMap.Point(114.522081844,38.0489583146), 15);
    // 初始化地图,设置中心点坐标和地图级别，缩放
	//添加地图类型控件
	map.addControl(new BMap.MapTypeControl({
		mapTypes:[
            BMAP_NORMAL_MAP,
            BMAP_HYBRID_MAP
        ]}));	  
	map.setCurrentCity("石家庄");          // 设置地图显示的城市 此项是必须设置的
	map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放

</script>
<script type="text/javascript">
	$(".dropdown-menu li a").on('click', function (){
  var selText = $(this).text();
  $(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class="caret"></span>');
});

$("#btnSearch").on('click', function (){
	// alert($('.btn-select').text()+", "+$('.btn-select2').text());
});
</script>

</body>

</html>




