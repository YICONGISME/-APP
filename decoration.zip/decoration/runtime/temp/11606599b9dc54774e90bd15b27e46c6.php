<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:85:"G:\xampp\htdocs\decoration\public/../application/admin\view\product\product_edit.html";i:1556523734;s:78:"G:\xampp\htdocs\decoration\public/../application/admin\view\public\header.html";i:1556435065;s:79:"G:\xampp\htdocs\decoration\public/../application/admin\view\public\base_js.html";i:1555913894;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>
           装饰品后台
        </title>
        <meta name="renderer" content="webkit">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="format-detection" content="telephone=no">
        <link rel="stylesheet" href="__STATIC__/css/x-admin.css" media="all">
    </head>

    
    <body>
        <div class="x-body">
            <form class="layui-form layui-form-pane" id="form" enctype="multipart/form-data" action="<?php echo url('update'); ?>" method="post">
                
                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">

                <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label">
                        标题
                    </label>
                    <div class="layui-input-block">
                        <input type="text" id="L_title" value="<?php echo $product['p_name']; ?>" name="p_name" required lay-verify="title"
                        autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label">
                        价格
                    </label>
                    <div class="layui-input-block">
                        <input type="number" id="L_title" value="<?php echo $product['p_price']; ?>" name="p_price" required lay-verify="title"
                        autocomplete="off" class="layui-input">
                    </div>
                </div>
                
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label" style="padding: 10px 0px 10px 0px;">
                            所在类别
                        </label>
                        <div class="layui-input-block">
                            <select name="p_cate_id">
                                <option value="0">顶级分类</option>
                                <?php if(is_array($cate) || $cate instanceof \think\Collection || $cate instanceof \think\Paginator): $i = 0; $__LIST__ = $cate;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if($product['p_cate_id'] == $vo['id']): ?>
                                <option value="<?php echo $vo['id']; ?>" selected><?php echo $vo['cate_name']; ?></option>
                                <?php else: ?>
                                <option value="<?php echo $vo['id']; ?>" ><?php echo $vo['cate_name']; ?></option>

                                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </div>
                    </div>
                </div>
                 <div class="layui-form-item">
                    <label for="link" class="layui-form-label" style="padding: 10px 0px 10px 0px;">
                        <span class="x-red">*</span>产品图片
                    </label>
                    <div class="layui-input-block">
                        <div class="site-demo-upbar" >
                        <input  type="file" name="p_img"  id="test">
                        </div>
                        <!-- 缩略图 -->
                        <img id="pre_img"  style="height: 30px;" src="/decoration/public/uploads/<?php echo $product['p_img']; ?>"/>
                        <input type="hidden" name="p_img" value="<?php echo $product['p_img']; ?>" >
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label">
                        简述
                    </label>
                    <div class="layui-input-block">
                        <input type="text" id="L_title" value="<?php echo $product['p_brief']; ?>" name="p_brief" required lay-verify="title"
                        autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item layui-form-text">
                    <div class="layui-input-block">
                        <textarea id="L_content" name="p_detail" 
                        placeholder="请输入详情信息" class="layui-textarea fly-editor" style="height: 160px;"><?php echo $product['p_detail']; ?></textarea>

                    </div>
                    <label for="L_content" class="layui-form-label" style="top: -2px;">
                        描述
                    </label>
                </div>

                <div class="layui-form-item">
                    <button class="layui-btn" lay-filter="add" lay-submit>
                        保存修改
                    </button>
                </div>
            </form>
        </div>
        <script src="__STATIC__/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/js/x-admin.js"></script>
<script src="__STATIC__/js/jquery.min.js"></script>
<script src="__STATIC__/js/x-layui.js"></script>
<!-- <script src="__STATIC__/layui/layui.js"></script> -->
<!-- <script src="__STATIC__/layui/layui.all.js"></script> -->

<!--引入boostrap-->
<link rel="stylesheet" type="text/css" href="__STATIC__/lib/bootstrap/css/bootstrap.css" />
<script type="text/javascript" src="__STATIC__/lib/bootstrap/js/bootstrap.js"></script>
       
        <script>
            layui.use(['form','layer','layedit','upload'], function(){
                $ = layui.jquery;
                var upload = layui.upload;
                var form = layui.form();
                layer = layui.layer;
                layedit = layui.layedit;



                layedit.set({
                  uploadImage: {
                    url: "./upimg.json" //接口url
                    ,type: 'post' //默认post
                  }
                })
  
                //创建一个编辑器
                editIndex = layedit.build('L_content');
 
            });
          
        </script>
        
       
    </body>

</html>