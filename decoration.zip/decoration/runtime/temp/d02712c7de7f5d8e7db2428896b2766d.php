<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:89:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\index\detail.html";i:1556543270;s:88:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\index\menu1.html";i:1556538999;s:90:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\public\header.html";i:1556527693;s:91:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\public\base_js.html";i:1556454279;s:90:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\public\footer.html";i:1555989510;}*/ ?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<!-- Latest Bootstrap min CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap.min.css" type="text/css">
	<!-- Dropdownhover CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap-dropdownhover.min.css" type="text/css">
	<!-- latest fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/font/css/font-awesome.min.css" type="text/css">
	<!-- simple line fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/simple-line-icon/css/simple-line-icons.css" type="text/css">
	<!-- stroke-gap-icons -->
	<link rel="stylesheet" href="__STATIC__/assets/stroke-gap-icons/stroke-gap-icons.css" type="text/css">
	<!-- Animate CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/animate.min.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/style.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/jcarousel.connected-carousels.css" type="text/css">
	<!--  baguetteBox -->
	<link rel="stylesheet" href="__STATIC__/assets/css/baguetteBox.css">
	<!-- Owl Carousel __STATIC__/assets -->
	<link href="__STATIC__/assets/owl-carousel/owl.carousel.css" rel="stylesheet">
	<link href="__STATIC__/assets/owl-carousel/owl.theme.css" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
</head>

<body>
<!--  Preloader  -->
<div id="preloader">
	<div id="loading">
	</div>
</div>
<header>
	<!--  top-header  -->
	<div class="top-header">
		<div class="container">

			<div class="col-md-6">
				<div class="top-header-left">
					<ul>
						<li>
							<i class="icon-location-pin icons" aria-hidden="true"></i>
							<a href="<?php echo url('index/index'); ?>">Hello 你好！</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-md-6">
				<div class="top-header-right">
					<ul>
						<?php if(\think\Session::get('user_id')): ?>
				        <li><a href="#"><?php echo \think\Session::get('user_id'); ?></a></li>
				        <?php else: ?>
				        <li><a href="<?php echo url('user/login'); ?>">登陆</a></li>
				        <li><a href="<?php echo url('user/register'); ?>">注册</a></li>
				        <?php endif; ?>
						<li>
							<div class="dropdown">
								<a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
									<i class="icon-settings icons" aria-hidden="true"></i> 设置
								</a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo url('admin/index/index'); ?>">管理中心</a></li>
									<li><a href="<?php echo url('user/logout'); ?>">退出登陆</a></li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>

		<!--  /top-header  -->
	</div>

<section class="top-md-menu">
	<div class="container">
		<div class="col-sm-3">
			<div class="logo">
				<h6><img src="__STATIC__/assets/images/logo.png" alt="logo" /></h6>
			</div>
		</div>
		<div class="col-sm-8">
			<!-- Search box Start -->
			<form action="<?php echo url('index/grid'); ?>" method="get" >
				<div class="well carousel-search hidden-phone">
					
					<div class="search">
						<input type="text" placeholder="搜索产品" name="keywords" style="padding-left: 50px;width: 84%;" />
					</div>
					<div class="btn-group">
						<button type="submit" onclick="search()" id="btnSearch" class="btn btn-primary" ><i class="fa fa-search" aria-hidden="true"></i></button>
					</div>
				</div>
			</form>
			<!-- Search box End -->
		</div>

		<div class="main-menu">
			<!--  nav  -->
			<nav class="navbar navbar-inverse navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" data-hover="dropdown" data-animations=" fadeInLeft fadeInUp fadeInRight">
					<ul class="nav navbar-nav">
						<li class="all-departments dropdown">
							<a href="<?php echo url('index/grid'); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span>产品分类</span> <i class="fa fa-bars" aria-hidden="true"></i> </a>
							<!-- <ul class="dropdown-menu dropdownhover-bottom all-open" role="menu"> -->
							<!-- 分类菜单列表 -->
							<ul class="dropdown-menu dropdownhover-bottom" role="menu">
							<?php if(is_array($cates) || $cates instanceof \think\Collection || $cates instanceof \think\Paginator): if( count($cates)==0 ) : echo "" ;else: foreach($cates as $key=>$vo): if($vo['cate_order'] != '3'): ?>
								<li class="dropdown">
									<a href="/decoration/public/index.php/index/index/grid?id=<?php echo $vo['id']; ?>"  value="<?php echo $vo['id']; ?>">
										<img src="__STATIC__/assets/images/menu-icon1.png" alt="menu-icon1" /> <?php echo $vo['cate_name']; ?> 
										<i class="fa fa-angle-right" aria-hidden="true"  style="margin-top: 5px;">
										</i>
									</a>
									
									<ul class="dropdown-menu right">
										<?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): if( count($vo['children'])==0 ) : echo "" ;else: foreach($vo['children'] as $key=>$vo1): ?>
										<li><a href="/decoration/public/index.php/index/index/grid?id=<?php echo $vo1['id']; ?>"><?php echo $vo1['cate_name']; ?></a>
										</li>
										<?php endforeach; endif; else: echo "" ;endif; ?>
									</ul>
									
								</li>
								<?php endif; endforeach; endif; else: echo "" ;endif; ?>	
							</ul>
						</li>
						<li><a href="<?php echo url('index/index'); ?>">首页</a></li>
						<li><a href="<?php echo url('index/grid'); ?>">产品网格</a></li>
						<li><a href="<?php echo url('index/contact'); ?>">联系我们</a></li>
					</ul>
					<!-- /.navbar-collapse -->
				</div>
			</nav>
			<!-- /nav end -->
		</div>
	</div>
</section>
<script src="__STATIC__/assets/js/jquery-3.3.1.min.js"></script>
<script src="__STATIC__/admin/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/admin/js/x-admin.js"></script>
<script src="__STATIC__/admin/js/jquery.min.js"></script>
<script src="__STATIC__/admin/js/x-layui.js"></script>

<!--  -->



	<!-- newsletter -->
	<section class="grid-shop">
		<!-- .grid-shop -->
		<div class="container">
			<div class="row">
					<div class="row">						
						<!-- left side -->
						<div class="col-sm-5 col-md-5">
							<!-- product gallery -->
							<div class="connected-carousels">
								<div class="stage">
									<div class="carousel carousel-stage">
										<ul>
											<?php if(is_array($pro_imgs) || $pro_imgs instanceof \think\Collection || $pro_imgs instanceof \think\Paginator): $i = 0; $__LIST__ = $pro_imgs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
											<li><img class="zoom_01" style="height: 500px;width:500px;padding: 15px;" src="/decoration/public/uploads/<?php echo $vo['url']; ?>" alt="qoute-icon" /> </li>
											<?php endforeach; endif; else: echo "" ;endif; ?>
											
											
										</ul>
									</div>
									<p class="photo-credits">
										Photos by <a href="http://www.mw-fotografie.de">Marc Wiegelmann</a>
									</p>
									<a href="#" class="prev prev-stage"><span>&lsaquo;</span></a>
									<a href="#" class="next next-stage"><span>&rsaquo;</span></a>
								</div>

								<div class="navigation" style="padding: 15px;">
									<a href="#" class="prev prev-navigation">&lsaquo;</a>
									<a href="#" class="next next-navigation">&rsaquo;</a>
									<div class="carousel carousel-navigation">
										<ul>
											<?php if(is_array($pro_imgs) || $pro_imgs instanceof \think\Collection || $pro_imgs instanceof \think\Paginator): $i = 0; $__LIST__ = $pro_imgs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

											<li><img src="/decoration/public/uploads/<?php echo $vo['url']; ?>" width="110" height="110" alt=""></li>
											<?php endforeach; endif; else: echo "" ;endif; ?>
											
										</ul>
									</div>
								</div>
							</div>

							<!-- / product gallery -->
						</div>
						<!-- left side -->
						<!-- right side -->
						<div class="col-sm-7 col-md-7">
							<!-- .pro-text -->
							<div class="pro-text product-detail">
								<!-- 查询出产品分类的名称 -->
								<!-- /.pro-img -->
								<?php if(is_array($cate_list) || $cate_list instanceof \think\Collection || $cate_list instanceof \think\Paginator): $i = 0; $__LIST__ = $cate_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cate): $mod = ($i % 2 );++$i;if($pro_detail['p_cate_id'] == $cate['id']): ?>
								<span class="span1"><?php echo $cate['cate_name']; ?></span>
								<?php endif; endforeach; endif; else: echo "" ;endif; ?>
								<a href="#">
									<h4><?php echo $pro_detail['p_name']; ?></h4>
								</a>
								<div class="star2">
									<ul>
										<li class="yellow-color"><i class="fa fa-star" aria-hidden="true"></i></li>
										<li class="yellow-color"><i class="fa fa-star" aria-hidden="true"></i></li>
										<li class="yellow-color"><i class="fa fa-star" aria-hidden="true"></i></li>
										<li class="yellow-color"><i class="fa fa-star" aria-hidden="true"></i></li>
										<li><i class="fa fa-star" aria-hidden="true"></i></li>
										<li><a href="#">10 review(s)</a></li>
										<li><a href="#"> Add your review</a></li>
									</ul>
								</div>
								<p><strong>￥<?php echo $pro_detail['p_price']; ?></strong><span class="line-through">$190.00</span></p>
								<p class="in-stock">Availability:   <span>In Stock</span></p>
								<p><?php echo $pro_detail['p_brief']; ?></p>							
								<ul class="ul-content">
									<li>《--品质保证--》</li>
									<li>《--七天无理由--》</li>
									<li>《--运费险--》</li>
									<li>《--环保更健康--》</li>
								</ul>

								<!-- <a href="#" class="addtocart2">Add to cart</a> -->
								 <button class="btn btn-danger" type="button" id="cart" p_cate_id="<?php echo $pro_detail['p_cate_id']; ?>" product_id="<?php echo $pro_detail['id']; ?>" session_id="<?php echo \think\Session::get('user_id'); ?>" style="margin-top: 10px;margin-left: 10px;">


<?php 

if(isset($is_cart)){
	echo "已加入收藏";
}
else{
	echo "加入收藏";
}

?>
								 </button>
								
								
								<a href="#" class="hart"><span class="icon icon-Heart"></span></a>
								<div class="share">
									<p>Share:</p>
									<ul>
										<li><a href="http://www.facebook.com/sharer.php?u=http://zcube.in/platin/platin/products-detail.html" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li> <a href="https://twitter.com/share?url=http://zcube.in/platin/platin/products-detail.html" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
										<li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=http://zcube.in/platin/platin/products-detail.html" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
									</ul>
								</div>
								<div class="tag">
									<p>Categories:
								<?php if(is_array($cate_list) || $cate_list instanceof \think\Collection || $cate_list instanceof \think\Paginator): $i = 0; $__LIST__ = $cate_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cate): $mod = ($i % 2 );++$i;if($pro_detail['p_cate_id'] == $cate['id']): ?>
								<span><?php echo $cate['cate_name']; ?></span>
								<?php endif; endforeach; endif; else: echo "" ;endif; ?>




									</p>
								</div>
							</div>
							<!-- /.pro-text -->
						</div>
					</div>
					<div class="row">
						<div class="tab-bg">
							<ul>
								<li class="active"><a data-toggle="tab" href="#home">Description</a></li>
								<!-- <li><a data-toggle="tab" href="#menu1">ADDITIONAL INFORMATION</a></li>
								<li><a data-toggle="tab" href="#menu2">REVIEWS (4)</a></li> -->
							</ul>
						</div>
						<div class="tab-content">
							<div id="home" class="tab-pane fade in active">
								<p><?php echo $pro_detail['p_detail']; ?></p>
							</div>
						</div>
					</div>
				</div>
				<!-- right side -->
			</div>
		</div>
		<!-- /.grid-shop -->
	</section>
<script src="__STATIC__/assets/js/jquery-3.3.1.min.js"></script>
<script src="__STATIC__/admin/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/admin/js/x-admin.js"></script>
<script src="__STATIC__/admin/js/jquery.min.js"></script>
<script src="__STATIC__/admin/js/x-layui.js"></script>


<script type="text/javascript">
	//处理收藏功能
	$(function(){
		$('#cart').on('click',function(){
			//获取当前的用户id和栏目id

			var pcateId = $(this).attr('p_cate_id')
			var proId = $(this).attr('product_id')
			var sessionId = $(this).attr('session_id')
			// console.log(pcateId);
			if(proId && pcateId){
				$.ajax({
					type:'get',
					url:"<?php echo url('index/index/fav'); ?>",
					data:{
						p_cate_id: 	pcateId,
						product_id: proId,
						session_id: sessionId,
						time: new Date().getTime()
					},
					dateType: 		'json',
					success : function(data){

						switch(data.status){
							case 1:
							$('#cart').attr('class','btn btn-danger')
							$('#cart').text(data.message)
							break;
							// alert(data.message);

							case 0:
							$('#cart').attr('class','btn btn-default')
							$('#cart').text(data.message)
							break;
							
							case -1:
							alert(data.message)
							break

							case -2:
							alert(data.message)
							break
						}
					}
				})
			}
		})
	})

</script>


<footer>
	<div class="container">
			<!-- copayright -->
			<div class="copayright">
				<div class="row text-center">
					
						Copyright &copy; 2019. All rights reserved.
				</div>
			</div>
			<!-- /copayright -->

		</div>
	</div>
</footer>
<p id="back-top">
	<a href="#top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>
</p>
<script src="__STATIC__/assets/js/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="__STATIC__/assets/js/bootstrap.min.js"></script>
<script src="__STATIC__/assets/js/bootstrap-dropdownhover.min.js"></script>
<!-- Plugin JavaScript -->
<script src="__STATIC__/assets/js/jquery.easing.min.js"></script>
<script src="__STATIC__/assets/js/wow.min.js"></script>
<!-- owl carousel -->
<script src="__STATIC__/assets/owl-carousel/owl.carousel.js"></script>
<!--  Custom Theme JavaScript  -->
<!-- <script src="__STATIC__/assets/js/custom.js"></script> -->
	<script type="text/javascript" src="__STATIC__/assets/js/jquery.jcarousel.min.js"></script>
	<script type="text/javascript" src="__STATIC__/assets/js/jcarousel.connected-carousels.js"></script>
	<script type="text/javascript" src="__STATIC__/assets/js/jquery.elevatezoom.js"></script>
	<script>
		$('.zoom_01').elevateZoom({
			zoomType: "inner",
			cursor: "crosshair",
			zoomWindowFadeIn: 500,
			zoomWindowFadeOut: 750
		});
	</script>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=3.0&ak=P39PpXRcSvYIugAGG4HKCiB3GVNncaKA"></script> 
<script type="text/javascript">
    // 百度地图API功能
    var map = new BMap.Map("map");
    map.centerAndZoom(new BMap.Point(114.522081844,38.0489583146), 15);
    // 初始化地图,设置中心点坐标和地图级别，缩放
	//添加地图类型控件
	map.addControl(new BMap.MapTypeControl({
		mapTypes:[
            BMAP_NORMAL_MAP,
            BMAP_HYBRID_MAP
        ]}));	  
	map.setCurrentCity("石家庄");          // 设置地图显示的城市 此项是必须设置的
	map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放

</script>
<script type="text/javascript">
	$(".dropdown-menu li a").on('click', function (){
  var selText = $(this).text();
  $(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class="caret"></span>');
});

$("#btnSearch").on('click', function (){
	// alert($('.btn-select').text()+", "+$('.btn-select2').text());
});
</script>

</body>

</html>

