<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:87:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\user\login.html";i:1556178079;s:90:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\public\header.html";i:1556527693;s:91:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\public\base_js.html";i:1556454279;s:90:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/index\view\public\footer.html";i:1555989510;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<!-- Latest Bootstrap min CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap.min.css" type="text/css">
	<!-- Dropdownhover CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/bootstrap-dropdownhover.min.css" type="text/css">
	<!-- latest fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/font/css/font-awesome.min.css" type="text/css">
	<!-- simple line fonts awesome -->
	<link rel="stylesheet" href="__STATIC__/assets/simple-line-icon/css/simple-line-icons.css" type="text/css">
	<!-- stroke-gap-icons -->
	<link rel="stylesheet" href="__STATIC__/assets/stroke-gap-icons/stroke-gap-icons.css" type="text/css">
	<!-- Animate CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/animate.min.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/style.css" type="text/css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="__STATIC__/assets/css/jcarousel.connected-carousels.css" type="text/css">
	<!--  baguetteBox -->
	<link rel="stylesheet" href="__STATIC__/assets/css/baguetteBox.css">
	<!-- Owl Carousel __STATIC__/assets -->
	<link href="__STATIC__/assets/owl-carousel/owl.carousel.css" rel="stylesheet">
	<link href="__STATIC__/assets/owl-carousel/owl.theme.css" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
</head>

<body>
<!--  Preloader  -->
<div id="preloader">
	<div id="loading">
	</div>
</div>
<header>
	<!--  top-header  -->
	<div class="top-header">
		<div class="container">

			<div class="col-md-6">
				<div class="top-header-left">
					<ul>
						<li>
							<i class="icon-location-pin icons" aria-hidden="true"></i>
							<a href="<?php echo url('index/index'); ?>">Hello 你好！</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-md-6">
				<div class="top-header-right">
					<ul>
						<?php if(\think\Session::get('user_id')): ?>
				        <li><a href="#"><?php echo \think\Session::get('user_id'); ?></a></li>
				        <?php else: ?>
				        <li><a href="<?php echo url('user/login'); ?>">登陆</a></li>
				        <li><a href="<?php echo url('user/register'); ?>">注册</a></li>
				        <?php endif; ?>
						<li>
							<div class="dropdown">
								<a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
									<i class="icon-settings icons" aria-hidden="true"></i> 设置
								</a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo url('admin/index/index'); ?>">管理中心</a></li>
									<li><a href="<?php echo url('user/logout'); ?>">退出登陆</a></li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>

		<!--  /top-header  -->
	</div>
	<!-- 主栏目 -->
	<div class="col-md-8">
		<div class="page-header">
		  <h2>用户登陆</h2>
		</div>
		<!-- 登陆表单 -->
		<form class="form-horizontal" method="post" id="login">
		  
		  <div class="form-group">
		    <label for="inputEmail2" class="col-sm-2 control-label">邮箱</label>
		    <div class="col-sm-10">
		      <input type="text" name="email" class="form-control" id="inputEmail2" placeholder="Email">
		    </div>
		  </div>
		  
		  <div class="form-group">
		    <label for="inputPassword4" class="col-sm-2 control-label">密码</label>
		    <div class="col-sm-10">
		      <input type="password" name="password" class="form-control" id="inputPassword4" placeholder="Password">
		    </div>
		  </div>
		  
		  
		  <div class="form-group">
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" id="submit" class="btn btn-primary">登陆</button>
		    </div>
		  </div>
		</form>		
	</div>
<script src="__STATIC__/assets/js/jquery-3.3.1.min.js"></script>
<script src="__STATIC__/admin/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/admin/js/x-admin.js"></script>
<script src="__STATIC__/admin/js/jquery.min.js"></script>
<script src="__STATIC__/admin/js/x-layui.js"></script>


	<!-- ajax提交当前表单 -->
<script>
	$(function(){
		$("#submit").on('click',function(){
			// alert($('#login').serialize());
			// ajax数据验证，json的字符串
			$.ajax({
				type:'post',
				url:"<?php echo url('index/user/loginCheck'); ?>",
				
				data:$('#login').serialize(),
				datatype:'json',
				// 请求成功后后调用的回调函数
				// success:function(data){
				// 	switch(data.status){
				// 		case 1:
				// 			alert(data.message);
				// 			window.location.href="<?php echo url('index/index'); ?>";
				// 			break;
				// 		case 0:
				// 		case -1:
				// 			alert(data.message);
				// 			window.location.back();

				// 	}
				// }
			})
			// alert('登陆成功');
			window.location.href="<?php echo url('index/index'); ?>";
		})
	})
</script>

<footer>
	<div class="container">
			<!-- copayright -->
			<div class="copayright">
				<div class="row text-center">
					
						Copyright &copy; 2019. All rights reserved.
				</div>
			</div>
			<!-- /copayright -->

		</div>
	</div>
</footer>
<p id="back-top">
	<a href="#top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>
</p>
<script src="__STATIC__/assets/js/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="__STATIC__/assets/js/bootstrap.min.js"></script>
<script src="__STATIC__/assets/js/bootstrap-dropdownhover.min.js"></script>
<!-- Plugin JavaScript -->
<script src="__STATIC__/assets/js/jquery.easing.min.js"></script>
<script src="__STATIC__/assets/js/wow.min.js"></script>
<!-- owl carousel -->
<script src="__STATIC__/assets/owl-carousel/owl.carousel.js"></script>
<!--  Custom Theme JavaScript  -->
<!-- <script src="__STATIC__/assets/js/custom.js"></script> -->
	<script type="text/javascript" src="__STATIC__/assets/js/jquery.jcarousel.min.js"></script>
	<script type="text/javascript" src="__STATIC__/assets/js/jcarousel.connected-carousels.js"></script>
	<script type="text/javascript" src="__STATIC__/assets/js/jquery.elevatezoom.js"></script>
	<script>
		$('.zoom_01').elevateZoom({
			zoomType: "inner",
			cursor: "crosshair",
			zoomWindowFadeIn: 500,
			zoomWindowFadeOut: 750
		});
	</script>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=3.0&ak=P39PpXRcSvYIugAGG4HKCiB3GVNncaKA"></script> 
<script type="text/javascript">
    // 百度地图API功能
    var map = new BMap.Map("map");
    map.centerAndZoom(new BMap.Point(114.522081844,38.0489583146), 15);
    // 初始化地图,设置中心点坐标和地图级别，缩放
	//添加地图类型控件
	map.addControl(new BMap.MapTypeControl({
		mapTypes:[
            BMAP_NORMAL_MAP,
            BMAP_HYBRID_MAP
        ]}));	  
	map.setCurrentCity("石家庄");          // 设置地图显示的城市 此项是必须设置的
	map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放

</script>
<script type="text/javascript">
	$(".dropdown-menu li a").on('click', function (){
  var selText = $(this).text();
  $(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class="caret"></span>');
});

$("#btnSearch").on('click', function (){
	// alert($('.btn-select').text()+", "+$('.btn-select2').text());
});
</script>

</body>

</html>