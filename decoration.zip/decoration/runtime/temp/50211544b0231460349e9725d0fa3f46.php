<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:80:"G:\xampp\htdocs\decoration\public/../application/admin\view\image\image_add.html";i:1555937521;s:78:"G:\xampp\htdocs\decoration\public/../application/admin\view\public\header.html";i:1556435065;s:79:"G:\xampp\htdocs\decoration\public/../application/admin\view\public\base_js.html";i:1555913894;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>
           装饰品后台
        </title>
        <meta name="renderer" content="webkit">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="format-detection" content="telephone=no">
        <link rel="stylesheet" href="__STATIC__/css/x-admin.css" media="all">
    </head>

    
    <body>
        <div class="x-body">
            <form class="layui-form layui-form-pane" action="<?php echo url('image/save'); ?>" enctype="multipart/form-data" method = "post" >
                
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label" style="padding: 10px 0px 10px 0px;">
                            所属产品
                        </label>
                        <div class="layui-input-block">
                            <select name="pid">
                                <option value="0">所有产品</option>
                                <?php if(is_array($products) || $products instanceof \think\Collection || $products instanceof \think\Paginator): $i = 0; $__LIST__ = $products;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo $vo['id']; ?>"><?php echo $vo['p_name']; ?></option>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </div>
                    </div>
                </div>
                 <div class="layui-form-item">
                    <label for="link" class="layui-form-label" style="padding: 10px 0px 10px 0px;">
                        <span class="x-red">*</span>产品图片
                    </label>
                    <div class="layui-input-block">
                        <div class="site-demo-upbar" >
                        <input  type="file" name="url[]"  id="test">
                        <input  type="file" name="url[]"  id="test">
                        <input  type="file" name="url[]"  id="test">
                        <input  type="file" name="url[]"  id="test">
                        <input  type="file" name="url[]"  id="test">
                        </div>
                        <!-- 缩略图 -->
                        <!-- <img id="pre_img"  style="height: 30px;" src=""/> -->
                        <input type="hidden" name="url" value="">
                    </div>
                </div>

               

                <div class="layui-form-item">
                    <button class="layui-btn" lay-filter="add" lay-submit>
                        立即发布
                    </button>
                </div>
            </form>
        </div>
        <script src="__STATIC__/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/js/x-admin.js"></script>
<script src="__STATIC__/js/jquery.min.js"></script>
<script src="__STATIC__/js/x-layui.js"></script>
<!-- <script src="__STATIC__/layui/layui.js"></script> -->
<!-- <script src="__STATIC__/layui/layui.all.js"></script> -->

<!--引入boostrap-->
<link rel="stylesheet" type="text/css" href="__STATIC__/lib/bootstrap/css/bootstrap.css" />
<script type="text/javascript" src="__STATIC__/lib/bootstrap/js/bootstrap.js"></script>
       
        <script>
            layui.use(['form','layer','layedit','upload'], function(){
                $ = layui.jquery;
                var upload = layui.upload;
                var form = layui.form();
                layer = layui.layer;
                layedit = layui.layedit;



                layedit.set({
                  uploadImage: {
                    url: "./upimg.json" //接口url
                    ,type: 'post' //默认post
                  }
                })
  
                //创建一个编辑器
                editIndex = layedit.build('L_content');
            
                
            });
              //监听提交
              /*form.on('submit(add)', function(data){
                console.log(data);
                //发异步，把数据提交给php
                layer.alert("增加成功", {icon: 6},function () {
                    // 获得frame索引
                    var index = parent.layer.getFrameIndex(window.name);
                    //关闭当前frame
                    parent.layer.close(index);
                });
                return false;
              });*/
              
              
          
        </script>
        
       
    </body>

</html>