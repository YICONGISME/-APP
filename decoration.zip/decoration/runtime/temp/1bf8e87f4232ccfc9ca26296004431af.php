<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:91:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/admin\view\user\user_edit.html";i:1556428687;s:90:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/admin\view\public\header.html";i:1555580784;s:91:"D:\phpStudy\PHPTutorial\WWW\decoration\public/../application/admin\view\public\base_js.html";i:1555913894;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>
            X-admin v1.0
        </title>
        <meta name="renderer" content="webkit">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="format-detection" content="telephone=no">
        <link rel="stylesheet" href="__STATIC__/css/x-admin.css" media="all">
    </head>
    
    <body>
        <div class="x-body">
            <form class="layui-form">
                <div class="layui-form-item">
                    <label for="email" class="layui-form-label">
                        <span class="x-red">*</span>邮箱
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="email" name="email" required="" lay-verify="required" value="<?php echo $user['email']; ?>"
                        autocomplete="off" class="layui-input" disabled>
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                        <span class="x-red">*</span>邮箱不得修改
                    </div>
                </div>

                <div class="layui-form-item">
                    <label for="L_email" class="layui-form-label">
                        <span class="x-red">*</span>用户名
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="name" name="name" required="" lay-verify="" value="<?php echo $user['name']; ?>"
                        autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                        <span class="x-red">*</span>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label for="L_email" class="layui-form-label">
                        <span class="x-red">*</span>手机号
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="mobile" name="mobile" required="" lay-verify="" value="<?php echo $user['mobile']; ?>"
                        autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                        <span class="x-red">*</span>
                    </div>
                </div>
                <?php if($user['is_admin'] == '1'): ?>

                <div class="layui-form-item">
                    <label for="L_email" class="layui-form-label">
                        <span class="x-red">*</span>是否管理员
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="is_admin" name="is_admin" required="" lay-verify="" value="<?php echo $user['is_admin']; ?>"
                        autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                        <span class="x-red">*</span>
                    </div>
                </div>
                <?php endif; ?>
                <div class="layui-form-item">
                    <label for="L_pass" class="layui-form-label">
                        <span class="x-red">*</span>新密码
                    </label>
                    <div class="layui-input-inline">
                        <input type="password" id="L_pass" name="password"  class="layui-input" value="" placeholder="密码">
                    </div>

                </div>

                <!--添加隐藏字段-->
                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">


                <div class="layui-form-item">
                    <label for="L_repass" class="layui-form-label">
                    </label>
                    <button  class="layui-btn" lay-filter="save" lay-submit="" id="submit">
                        保存
                    </button>
                </div>
            </form>
        </div>
       <script src="__STATIC__/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/js/x-admin.js"></script>
<script src="__STATIC__/js/jquery.min.js"></script>
<script src="__STATIC__/js/x-layui.js"></script>
<!-- <script src="__STATIC__/layui/layui.js"></script> -->
<!-- <script src="__STATIC__/layui/layui.all.js"></script> -->

<!--引入boostrap-->
<link rel="stylesheet" type="text/css" href="__STATIC__/lib/bootstrap/css/bootstrap.css" />
<script type="text/javascript" src="__STATIC__/lib/bootstrap/js/bootstrap.js"></script>
        <script>
            layui.use(['form','layer'], function(){
                $ = layui.jquery;
              var form = layui.form()
              ,layer = layui.layer;
            
            });

            $(function(){
                $('#submit').on('click',function(){
                    $.ajax({
                        type:'POST',
                        url:"<?php echo url('user/update'); ?>",
                        data:$('.layui-form').serialize(),
                        datatype:'json',
                        success:function(data){
                            if(data.status ==1 ){
                                alert(data.message);
                                parent.window.location.reload();
                            }else{
                                alert(data.message);
                                window.location.href="<?php echo url('user/edit'); ?>";
                            }
                        }
                    })
                return false;
                })
            })
            

        </script>