<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:79:"G:\xampp\htdocs\decoration\public/../application/admin\view\user\user_list.html";i:1556608270;s:78:"G:\xampp\htdocs\decoration\public/../application/admin\view\public\header.html";i:1556435065;s:79:"G:\xampp\htdocs\decoration\public/../application/admin\view\public\base_js.html";i:1555913894;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>
           装饰品后台
        </title>
        <meta name="renderer" content="webkit">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="format-detection" content="telephone=no">
        <link rel="stylesheet" href="__STATIC__/css/x-admin.css" media="all">
    </head>
    <body>
        <div class="x-nav">
            <span class="layui-breadcrumb">
              <a><cite>首页</cite></a>
              <a><cite>会员管理</cite></a>
              <a><cite>管理员列表</cite></a>
            </span>
            <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right"  href="javascript:location.replace(location.href);" title="刷新"><i class="layui-icon" style="line-height:30px">ဂ</i></a>
        </div>
        <div class="x-body">
        <xblock><button class="layui-btn layui-btn-danger" onclick="delAll()"><i class="layui-icon">&#xe640;</i>批量删除</button></xblock>
            <table class="layui-table">
                <thead>
                    <tr>

                        <th>
                            ID
                        </th>
                        <th>
                            登录名
                        </th>

                        <th>
                            邮箱
                        </th>

                        
                        
                        <th>
                            操作
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(is_array($user) || $user instanceof \think\Collection || $user instanceof \think\Paginator): $i = 0; $__LIST__ = $user;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                    <tr>
                        <td>
                            <input type="checkbox" value="<?php echo $vo['id']; ?>" name="id[]">
                        </td>
                        <td>
                            <?php echo $vo['id']; ?>
                        </td>
                        <td>
                            <?php echo $vo['name']; ?>
                        </td>

                        <td >
                            <?php echo $vo['email']; ?>
                        </td>

                        <td class="td-manage">

                            <a title="编辑" href="javascript:;" onclick="user_edit('编辑','<?php echo url("user/edit"); ?>'+'?id='+<?php echo $vo['id']; ?>,'4','','510')"
                               class="ml-5" style="text-decoration:none">
                                <i class="layui-icon">&#xe642;</i>
                            </a>
                            <a title="删除" href="javascript:;" onclick="user_del(this,'<?php echo $vo['id']; ?>')" 
                            style="text-decoration:none">
                                <i class="layui-icon">&#xe640;</i>
                            </a>

                        </td>
                        
                    </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                </tbody>
            </table>

            <div id="page"></div>
        </div>
        <script src="__STATIC__/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/js/x-admin.js"></script>
<script src="__STATIC__/js/jquery.min.js"></script>
<script src="__STATIC__/js/x-layui.js"></script>
<!-- <script src="__STATIC__/layui/layui.js"></script> -->
<!-- <script src="__STATIC__/layui/layui.all.js"></script> -->

<!--引入boostrap-->
<link rel="stylesheet" type="text/css" href="__STATIC__/lib/bootstrap/css/bootstrap.css" />
<script type="text/javascript" src="__STATIC__/lib/bootstrap/js/bootstrap.js"></script>
        <script>
            layui.use(['laydate','element','laypage','layer'], function(){
                $ = layui.jquery;//jquery
              laydate = layui.laydate;//日期插件
              lement = layui.element();//面包导航

              layer = layui.layer;//弹出层

              //以上模块根据需要引入

              laypage({
                cont: 'page'
                ,pages: 100
                ,first: 1
                ,last: 100
                ,prev: '<em><</em>'
                ,next: '<em>></em>'
              });

            });
       //编辑
            function user_edit (title,url,id,w,h) {


                x_admin_show(title,url,w,h);

            }



            function user_del(obj,id){
                layer.confirm('确认要删除吗？',function(index){
                    //发异步删除数据
                      $.get("<?php echo url('user/delete'); ?>",{id:id});
                    $(obj).parents("tr").remove();
                    layer.msg('已删除!',{icon:1,time:1000});
                });
            }
            //批量删除提交
             function delAll () {
               var chk_value =[]; 
              $('input[name="id[]"]:checked').each(function(){ 
                chk_value.push($(this).val()); 
              }); 
              // console.log(chk_value);
                layer.confirm('确认要删除吗？',function(index){
                    //捉到所有被选中的，发异步进行删除
                     $.post("<?php echo url('user/delAll'); ?>", {data:chk_value}, function(res) {
                          if(res.status == 1) {
                            layer.msg(res.message, {icon: 1, time: 1000});
                          } else {
                            layer.msg(res.message, {icon: 2, time: 1000});
                          }
                          setTimeout(function() {
                            location.reload();
                          }, 1000);
                        });
                    
                });
             }


            </script>

    </body>
</html>