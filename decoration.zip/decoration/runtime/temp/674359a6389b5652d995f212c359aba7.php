<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:79:"G:\xampp\htdocs\decoration\public/../application/admin\view\cate\cate_edit.html";i:1556433057;s:78:"G:\xampp\htdocs\decoration\public/../application/admin\view\public\header.html";i:1556435065;s:79:"G:\xampp\htdocs\decoration\public/../application/admin\view\public\base_js.html";i:1555913894;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>
           装饰品后台
        </title>
        <meta name="renderer" content="webkit">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="format-detection" content="telephone=no">
        <link rel="stylesheet" href="__STATIC__/css/x-admin.css" media="all">
    </head>

    
    <body>
        <div class="x-body">
            <form class="layui-form">
                <input type="hidden" name="id" value="<?php echo $cate_now['id']; ?>">

                <div class="layui-form-item">
                    <label for="cname" class="layui-form-label">
                        ID
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="id" name="id" value="<?php echo $cate_now['id']; ?>" required="" lay-verify="required"
                        autocomplete="off"  value="1" disabled="" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="cname" class="layui-form-label">
                        <span class="x-red">*</span>分类名
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="cate_name" name="cate_name"  value="<?php echo $cate_now['cate_name']; ?>" required="" lay-verify="required"
                        autocomplete="off" class="layui-input">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label for="cate_order" class="layui-form-label">
                        <span class="x-red">*</span>排序
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="cate_order" name="cate_order" required="" lay-verify="required"
                               autocomplete="off" class="layui-input" value="<?php echo $cate_now['cate_order']; ?>">
                    </div>
                </div>


                <div class="layui-form-item">
                    <label class="layui-form-label">所属分类</label>
                    <div class="layui-input-inline" >
                        <select name="pid">
                        <option value="0">顶级分类</option>
                        <?php if(is_array($cate) || $cate instanceof \think\Collection || $cate instanceof \think\Paginator): $i = 0; $__LIST__ = $cate;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <!-- 判断当前编辑的分类的父id 和菜单列表中的id -->
                        <?php if($cate_now['pid'] == $vo['id']): ?>
                            <option value="<?php echo $vo['id']; ?>" selected><?php echo $vo['cate_name']; ?></option>
                            <?php else: ?>
                            <option value="<?php echo $vo['id']; ?>" ><?php echo $vo['cate_name']; ?></option>
                        <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </div>
                </div>
                
                <div class="layui-form-item">
                    <label for="L_repass" class="layui-form-label">
                    </label>
                    <button  class="layui-btn" lay-filter="save" lay-submit="">
                        保存
                    </button>
                </div>
            </form>
        </div>
        <script src="__STATIC__/lib/layui/layui.js" charset="utf-8"></script>
<script src="__STATIC__/js/x-admin.js"></script>
<script src="__STATIC__/js/jquery.min.js"></script>
<script src="__STATIC__/js/x-layui.js"></script>
<!-- <script src="__STATIC__/layui/layui.js"></script> -->
<!-- <script src="__STATIC__/layui/layui.all.js"></script> -->

<!--引入boostrap-->
<link rel="stylesheet" type="text/css" href="__STATIC__/lib/bootstrap/css/bootstrap.css" />
<script type="text/javascript" src="__STATIC__/lib/bootstrap/js/bootstrap.js"></script>
       
        <script>
            layui.use(['form','layer'], function(){
                $ = layui.jquery;
              var form = layui.form()
              ,layer = layui.layer;
            

                //监听提交
                form.on('submit(save)', function(data){
                    console.log(data);
                    //发异步，把数据提交给php
                    $.post('<?php echo url("update"); ?>',data.field,function(res){

                        if (res.status== 1) {
                            layer.alert(res.message, {icon: 6},function () {
                                // 获得frame索引
                                var index = parent.layer.getFrameIndex(window.name);
                                //关闭当前frame
                                parent.layer.close(index);
 
                            });
                                parent.window.location.reload();

                        }else{
                            layer.alert(res.message, {icon: 6},function(){   
                                // 获得frame索引
                                var index = parent.layer.getFrameIndex(window.name);
                                //关闭当前frame
                                parent.layer.close(index);  
                            });
                        }
                    });

                    return false;
                 
                });
              
            });
        </script>
        
    </body>

</html>