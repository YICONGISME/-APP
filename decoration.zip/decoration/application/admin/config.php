<?php
//配置文件
return [
    // 视图输出字符串内容替换
    'view_replace_str'       => [
		'__STATIC__' => '/decoration/public/static/admin',
	],
];