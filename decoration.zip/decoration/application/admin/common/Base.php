<?php
namespace app\admin\common;
use think\Controller;
use think\Session;
use think\Request;
use app\admin\model\System;

class Base extends Controller
{
	protected function _initialize()
	{
		define('USER_ID',Session::get('user_id'));

	}



	//判断用户是否重复登陆
	//由于在多个页面都需要用到，设置为基础类
	protected function logined()
	{	
		if(Session::has('user_id')){
			$this->error('登陆成功，正在跳转','index/index');
		}
	}

	// 前台判断用户是否登陆
	protected function isLogin()
	{
		if(!Session::has('user_id')){
			$this->error('客官，您还没有登陆。','index/user/login');
		}
	}

	//后台判断用户登录
	protected function isLogined()
	{	
		if(!Session::has('user_id')){
			$this->error('客官，您还没有登陆。','login/index');
		}
	}
	// 前台判断用户重复登陆

	protected function alreadyLogin()
	{
		if(!is_null(USER_ID))
		{
			$this->error('您已登录，不能重复登录~~~','index/index/index');
		}
	}

	protected function alreadyLogined()
	{
		if(!is_null(USER_ID))
		{
			$this->error('您已登录，不能重复登录~~~','admin/index/index');
		}
	}


	//获取系统信息
	public function getSystem()
	{
		
		return System::get(1);
	}

	//获取系统开启状态
	  //$request请求对象,$config当前配置信息
	public function getStatus($request,$config)
	{
		//判断当前模块是不是admin
		if($request->module() !== 'admin')
		{
            //根据当前配置表中的is_close值来进行判断,如果为1关闭,0则开启,0是默认,我们什么都不做，就是开启
			if($config-> is_close == 1)
			{
				$this->error('网站已关闭');
				exit();
			}
		}
	}
}