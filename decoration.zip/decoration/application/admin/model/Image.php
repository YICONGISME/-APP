<?php
namespace app\admin\model;
use think\Model;
use think\Collection;
class Image extends Model
{
}