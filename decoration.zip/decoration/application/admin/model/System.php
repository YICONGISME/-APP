<?php
namespace app\admin\model;
use think\Model;

class System extends Model
{
	
}
?>