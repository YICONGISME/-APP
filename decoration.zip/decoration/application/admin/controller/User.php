<?php

namespace app\admin\controller;
use app\admin\common\Base;
use think\Request;
use app\admin\model\User as UserModel;
use think\Session;
class User extends Base
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index()
    {

        //1.获取到当前用户的id和级别is_admin
        $data['user_id'] = Session::get('user_info.id');
        $data['is_admin'] = Session::get('is_admin');

        //2.获取当前用户的信息
        $user = UserModel::where('id',$data['user_id'])->select();
        //3.如果是超级管理员，获取全部信息
        if($data['is_admin'] == 1)
        {
            $user = UserModel::select();
        }
        
        //渲染模板
        $this->view->assign('user',$user);
        return $this->view->fetch('user_list');

    }

    

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit(Request $request)
    {
        //根据传递过来的参数id，获取当前要编辑的管理员信息
        $user = UserModel::get($request->param('id'));
        //赋值模板变量，以便在编辑页面渲染管理员信息
        $this->view->assign('user',$user);
        return $this->view->fetch('user_edit');

    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        if($request->isAjax(true))
        {
            //获取提交的数据，自动过滤空值
            $id = $request->param('id');
            // dump($id);
            $data = array_filter($request->param());
            if(isset($data['password']) )
            {
                $data['password'] = md5($data['password']);
            }else{
                $u = UserModel::get(['id'=>$id]);
                $data['password'] = $u['password'];
            }
            //更新用户表
            $res = UserModel::update($data)->where('id',$id);

            $status = 1;
            $message = '更新成功';

            //更新失败
            if(is_null($res)){
                $status = 0;
                $message = '更新失败';
            }
        }   
        return ['status'=>$status,'message'=>$message];
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id ,Request $request)
    {
        $id  = $this->request->get('id');
        UserModel::destroy($id);

    }
    public function delAll(Request $request) {
        
        $getid = $this->request->param('data/a'); //获取选择的复选框的值
        // dump($getid);
        if (!$getid){
            $this->error('未选择记录'); //没选择就提示信息
        }
        $getids = implode(',', $getid); //选择一个以上，就用,把值连接起来(1,2,3)这样
        $id = is_array($getid) ? $getids : $getid; //如果是数组，就把用,连接起来的值覆给$id,否则就覆获取到的没有,号连接起来的值
         //最后进行数据操作,
        $res = UserModel::destroy($id);
        if($res)
        {
        return ['status'=>1,'message'=>"删除成功"];         
        }
    }

}
