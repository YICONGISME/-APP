<?php

namespace app\admin\controller;
use app\admin\common\Base;
use app\admin\model\User;
use think\Request;
use think\Session;
class Login extends Base
{
    // 渲染登录页面
    public function index()
    {
        $this->alreadyLogined();
        

        return $this->view->fetch('login');
    }

   //验证用户登录
    public function check(Request $request)
    {   
        //没有用静态方法，所以先实例化request
        //获取用户输入
        $data = $request->param();
        $email = $data['email'];
        $password = md5($data['password']);

        //根据用户输入，构造查询条件
        $map = ['email'=>$email];
        //用模型进行查询
        $user = User::get($map);

        //设置一下验证状态
        $status = 0;
        //将用户名和密码分开验证

        //如果没有查询到用户
        if(is_null($user))
        {
            //设置返回信息
            $message = "用户不存在";
            // 把查询到的数据的密码字段值和用户提交的相比较
        }elseif($user->password != $password){
            $message = "密码不正确";
        }else{
            // 如果用户名和密码都验证通过，则用户合法
            // 修改返回信息
            $status = 1;
            $message = "验证通过，点击确定进入后台";

            // 将用户信息保存到session中
            Session::set('user_id',$user->name);
            // 只能存储到username和password字段，其他字段不能存储
            // Session::set('user_info',$user);
            Session::set('is_admin',$user['is_admin']);

            // $user->inArray()获取包含获取器处理的全部数据属性的话
            Session::set('user_info',$user->toArray());
        }
        return ['status'=> $status,'message'=>$message];
    }

    //退出登录
    public function logout()
    {
        //删除用户的session
        Session::delete('user_id');
        Session::delete('user_info');

        //执行成功，返回登录页面
        $this->success('退出成功,正在返回~~~','login/index');
    }

    
}
