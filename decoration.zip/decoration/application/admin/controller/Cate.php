<?php
namespace app\admin\controller;
use app\admin\common\Base;
use app\admin\model\Cate as CateModel;
use think\Request;

class Cate extends Base
{
	public function index()
    {
        //获取分类信息
        $cate = CateModel::getCate();

        //用模型获取分页数据
        $cate_list = CateModel::order(['id desc'])->paginate(20);
       
        //获取记录总数
        $count = CateModel::count();

        //模板赋值
        $this->view->assign('cate_list',$cate_list);//无层级信息
        $this->view->assign('count',$count);
        $this->view->assign('cate',$cate);//有层级信息
        
        //模板渲染
        return $this->view->fetch('cate_list');

    }
    
    public function create(Request $request)
    {
        //
         $status =1 ;
        $message = "添加成功";

        $res = CateModel::create(
            [
                'cate_name'=>$request->param('cate_name'),
                'cate_order'=>$request->param('cate_order'),
                'pid' => $request->param('pid'),
            ]);
        if(is_null($res)){
            $status = 0 ;
            $message ="添加失败";
        }

        return ['status'=>$status,'message'=>$message,'res'=>$res->toJson()];

    }


     public function edit($id ,Request $request)
    {
        //获取要编辑的记录
        $id  = $this->request->get('id');
        $cate_now = CateModel::get($id);
        $cate = CateModel::getCate();

        $this->view->assign('cate',$cate);//有层级信息
        $this->view->assign('cate_now',$cate_now);
        return $this->view->fetch('cate_edit');
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update()
    {
       
            
             //1.获取一下提交的数据,包括上传文件
            $data = $this->request->param(true);
            
            $res = CateModel::update($data,['id'=>$data['id']]); 

             $status = 1;
            $message = "更新成功"; 

            //如果更新失败
            if(is_null($res)){
                $status = 0;
                $message = "更新失败";
            }
        

        //返回更新结果
        return ['status'=>$status,'message'=>$message];
    }

    public function delete($id ,Request $request)
    {
        $id  = $this->request->get('id');
        CateModel::destroy($id);

    }
    public function delAll(Request $request) {
        
        $getid = $this->request->param('data/a'); //获取选择的复选框的值
        // dump($getid);
        if (!$getid){
            $this->error('未选择记录'); //没选择就提示信息
        }
        $getids = implode(',', $getid); //选择一个以上，就用,把值连接起来(1,2,3)这样
        $id = is_array($getid) ? $getids : $getid; //如果是数组，就把用,连接起来的值覆给$id,否则就覆获取到的没有,号连接起来的值
         //最后进行数据操作,
        $res = CateModel::destroy($id);
        if($res)
        {
        return ['status'=>1,'message'=>"删除成功"];         
        }
    }

}