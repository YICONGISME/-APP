<?php
namespace app\admin\controller;
use app\admin\common\Base;
use app\admin\model\Contact as ContactModel;
use think\Request;
class Contact extends Base
{
	public function index()
	{
		$contact = ContactModel::paginate(8);
		$this->view->assign('contact',$contact);
		return $this->view->fetch('contact_list');
	}

	public function delete($id ,Request $request)
    {
        $id  = $this->request->get('id');
        ContactModel::destroy($id);

    }
    public function delAll(Request $request) {
    	
		$getid = $this->request->param('data/a'); //获取选择的复选框的值
        // dump($getid);
        if (!$getid){
            $this->error('未选择记录'); //没选择就提示信息
        }
        $getids = implode(',', $getid); //选择一个以上，就用,把值连接起来(1,2,3)这样
        $id = is_array($getid) ? $getids : $getid; //如果是数组，就把用,连接起来的值覆给$id,否则就覆获取到的没有,号连接起来的值
    	 //最后进行数据操作,
		$res = ContactModel::destroy($id);
		if($res)
		{
		return ['status'=>1,'message'=>"删除成功"];			
		}
    }

}