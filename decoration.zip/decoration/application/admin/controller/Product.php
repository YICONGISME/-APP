<?php

namespace app\admin\controller;
use app\admin\model\Cate as CateModel;
use app\admin\model\Product as ProductModel;

use app\admin\common\Base;
use think\Validate;
use think\Request;

class Product extends Base
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index()
    {
        //查询所有的产品
        $products = ProductModel::order(['id desc'])->paginate(20);

        //查询所有的分类
        $cate_list = CateModel::all();

        $this->view->assign('products',$products);
        $this->view->assign('cate_list',$cate_list);

        return $this->view->fetch('product_list');

    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
        //获取分类信息
        $cate = CateModel::getCate();

        //用模型获取分页数据

        //获取记录总数
        $count = CateModel::count();

        //模板赋值
        $this->view->assign('count',$count);
        $this->view->assign('cate',$cate);//有层级信息

        return $this->view->fetch('product_add');

    }


    

    public function save(Request $request)
    {
        if($this->request->isPost()){
            
             //1.获取一下提交的数据,包括上传文件
            $data = $this->request->param(true);

            //获取上传的文件对象
            $file = $this->request->file('p_img');

            // 判断是否获取到了文件
            if(empty($file))
            {
                $this->error("请选择图片");
            }

            //上传文件
            $map = [
                'ext' => 'jpg,jpeg,png',
                'size' => 3000000,
            ];
            $info = $file->validate($map)->move(ROOT_PATH.'public/uploads/');
            
            if(is_null($info))
            {
                $this->error($file->getError());
            }
            
            //向表中新增数据
            $data['p_img'] = $info ->getSaveName();
            $res = ProductModel::create($data);

            if($res)
            {
                $this->success('添加成功');
            }else{
                $this->error('添加失败');
            }
        }else{
            $this->error('请求类型错误');
        }
        
    }


     public function edit($id ,Request $request)
    {
        //获取要编辑的记录
        $id  = $this->request->get('id');
        $product = ProductModel::get($id);
        // dump($product);
        $cate = CateModel::getCate();
        $this->view->assign('cate',$cate);//有层级信息

        $this->view->assign('product',$product);
        return $this->view->fetch('product_edit');
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update()
    {
        if($this->request->isPost()){
            
             //1.获取一下提交的数据,包括上传文件
            $data = $this->request->param(true);
            // dump($data['p_img']);
            $file = $this->request->file('p_img');

            if(isset($file))
            {
                    //上传文件
                $map = [
                    'ext' => 'jpg,jpeg,png',
                    'size' => 3000000,
                ];

                $info = $file->validate($map)->move(ROOT_PATH.'public/uploads/');

                if(is_null($info))
                {
                    $this->error($file->getError());
                }
                $data['p_img'] = $info ->getSaveName();

            }
            //获取上传的文件对象

            // 判断是否获取到了文件
            /*if(empty($file))
            {
                $this->error($file->getError());
            }*/
            
            //向表中修改数据
            // $res = ProductModel::update($data);
            $res =ProductModel::update($data,['id'=>$data['id']]); 

            if($res)
            {
                $this->success('修改成功');

            }else{
                $this->error('修改失败');
            }
        }else{
            $this->error('请求类型错误');
        }
    }

    public function delete($id ,Request $request)
    {
        $id  = $this->request->get('id');
        ProductModel::destroy($id);

    }
    public function delAll(Request $request) {
        
        $getid = $this->request->param('data/a'); //获取选择的复选框的值
        // dump($getid);
        if (!$getid){
            $this->error('未选择记录'); //没选择就提示信息
        }
        $getids = implode(',', $getid); //选择一个以上，就用,把值连接起来(1,2,3)这样
        $id = is_array($getid) ? $getids : $getid; //如果是数组，就把用,连接起来的值覆给$id,否则就覆获取到的没有,号连接起来的值
         //最后进行数据操作,
        $res = ProductModel::destroy($id);
        if($res)
        {
        return ['status'=>1,'message'=>"删除成功"];         
        }
    }


}