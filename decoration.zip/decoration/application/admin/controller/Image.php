<?php

namespace app\admin\controller;
use app\admin\model\Image as ImageModel;
use app\admin\model\Product as ProductModel;

use app\admin\common\Base;

use think\Request;

class Image extends Base
{

public function index()
    {
        //查询所有的图片
        $images = ImageModel::order(['id desc'])->paginate(20);

        //查询所有的产品
        $pro_list = ProductModel::all();

        $this->view->assign('images',$images);
        $this->view->assign('pro_list',$pro_list);

        return $this->view->fetch('image_list');

    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
        //获取分类信息
        $products= ProductModel::all();

        //用模型获取分页数据

        //获取记录总数
        // $count = CateModel::count();

        //模板赋值
        $this->view->assign('products',$products);//有层级信息

        return $this->view->fetch('image_add');

    }

	public function save(Request $request)
	{
		// 注意上传多张图片，不能是同一张
        if($this->request->isPost()){
        
	        $data = $this->request->param(true);

		    // 获取表单上传文件
		    $files = $this->request->file('url');
		    // dump($files);
		    // exit();
		    // 判断是否获取到了文件
	        if(empty($files))
	        {
	            $this->error($files->getError());
	        }

		    foreach($files as $file){
		    	
		        // 移动到框架应用根目录/public/uploads/ 目录下
		        $info = $file->validate(['size'=>6000000,'ext'=>'jpg,png,gif'])->move(ROOT_PATH . 'public' . DS . 'uploads');
		     
		       if(is_null($info))
	            {
	                $this->error($file->getError());
	            }
	            
	            //向表中新增数据
	          
	            $data['url'] = $info->getSaveName();
	            // dump($data['url']);
	            $res = ImageModel::create($data);
		    }
		    if($res)
		    {
		    return "添加成功";
		    	
		    }
		}else{
            $this->error('请求类型错误');
        }
	}

	public function delete($id ,Request $request)
    {
        $id  = $this->request->get('id');
        ImageModel::destroy($id);

    }

    public function delAll(Request $request) {
    	
		$getid = $this->request->param('data/a'); //获取选择的复选框的值
        // dump($getid);
        if (!$getid){
            $this->error('未选择记录'); //没选择就提示信息
        }
        $getids = implode(',', $getid); //选择一个以上，就用,把值连接起来(1,2,3)这样
        $id = is_array($getid) ? $getids : $getid; //如果是数组，就把用,连接起来的值覆给$id,否则就覆获取到的没有,号连接起来的值
    	 //最后进行数据操作,
		$res = ImageModel::destroy($id);
		if($res)
		{
		return ['status'=>1,'message'=>"删除成功"];			
		}
    }



}
?>