<?php
namespace app\index\controller;
use app\admin\common\Base;
use app\index\model\User as UserModel;//因为和本类重名
use think\Request;
use think\Session;
// use app\common\validate\User;
// 对应user表
class User extends Base
{
	// 注册页面
	public function register()
	{
		// $this->is_reg();
		//模板变量赋值
		$this->assign('title','用户注册');
		// 加载模板输出
		return $this->fetch();
	}

	//处理用户提交的注册信息
	public function insert(Request $request)
	{
		if($this->request->isAjax()){

			$data = $this->request->post();//要验证的数据 获取到post的数据
			dump($data);
			// exit();
			$rule =[
					'name|姓名'=>'require|length:2,20',
					'email|邮箱'=>'require|email|unique:user',
					// 'mobile|手机'=>'require|mobile|number',
					'password|密码'=>'require|length:3,20'
					];//自定义的验证规则
			//开始验证
			$res = $this->validate($data,$rule);
			if(true !== $res){
				return ['status'=>-1,'message'=> $res];
			}else{
				//except()方法用于排除password_confirm字段
				// $data = Request::except('password_confirm','post');
				//使用模型来创建数据
				// 获取用户表单的数据
				$data['password'] = md5($data['password']);
				if($user = UserModel::create($data)){//返回的是一个模型对象，字段就是他的属性
					// 实现注册后自动登陆
					// $res = UserModel::get($user->id);//获取插入数据的id
					Session::set('user_id',$user->name);
					// Session::set('user_name',$res->name);

					// 返回的是php数组
					// return ['status'=>1,'message'=>'恭喜，注册成功'];
					exit(json_encode(array('status'=>1,'message'=>'恭喜，注册成功')));

					// json_encode($data);
					//结果： {"status":1,"message":"恭喜"}
				}else{
					return ['status'=>0,'message'=>'注册失败'];
				}
			}
			
		}else{

			$this->error('请求类型错误','register');
		}
	} 

	public function login()
	{

		$this->logined();//由于ajax出错，此处先用此方法代替
        // $this->alreadyLogin(); //防止用户重复登陆

		return $this->view->fetch('login',['title'=>'用户登陆']);
	}

	//用户登陆验证与查询
	public function loginCheck()
	{
		if($this->request->isAjax()){

			$data = $this->request->post();//要验证的数据
			$rule = [
				'email|邮箱'=>'require|email',
				'password|密码'=>'require',
			];//自定义的验证规则
			//开始验证
			$res = $this->validate($data,$rule);
			if(true !== $res){
				return ['status'=>-1,'message'=> $res];
			}else{
				//从数据库查询信息，使用闭包函数，使用外部的data数据
				$result =  UserModel::get(function($query) use ($data){
					$query->where('email',$data['email'])
					->where('password',md5($data['password']));
				});

				if(null == $result){
					
					return ['status'=>0,'message'=>'邮箱或密码不正确'];
				}else{
					//将用户的信息存储到session
					Session::set('user_id',$result->name);
            		Session::set('user_info',$result->toArray());
					Session::set('is_admin',$result['is_admin']);

					// Session::set('user_name',$result->name);

					// return ['status'=>1,'message'=>'恭喜，登陆成功'];
					exit(json_encode(array('status'=>1,'message'=>'恭喜，登陆成功')));

				}
			}
			
		}else{

			$this->error('请求类型错误','login');
		}
	}

	// 用户退出登陆
	public function logout()
	{
		/*1.
		Session::delete('user_id');
		Session::delete('user_name');
		*/	
		//2.
		Session::clear();
		
		// Session::destory();	此方法在这不行
		$this->success("退出登录成功",'index/index');//成功退出，跳转到首页
	}





} 


?>