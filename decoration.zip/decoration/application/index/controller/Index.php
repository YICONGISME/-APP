<?php
namespace app\index\controller;
use app\admin\common\Base;
use app\admin\model\Cate as CateModel;
use app\index\model\Cate as CateIndex;
use app\index\model\Product as ProductIndex;
use app\index\model\Image as ImageIndex;
use app\index\model\Cart as CartIndex;
use app\index\model\Contact as ContactIndex;
use app\index\model\Slide as SlideIndex;

use think\Session;
use think\Request;
use think\Db;
class Index extends Base
{

    public function index(Request $request)
    {
        
    	// $cates = CateIndex::getCate();  
         //每个页面都需要使用此变量，因此都要赋值 
        $menu_list = Db::table('cate')->select();
        // dump($menu_list);
        // 二级菜单实现
        $cates = [];
        foreach ($menu_list as $v) {
            if($v['pid'] == 0)
            {
                foreach ($menu_list as $v1) {
                    if($v1['pid'] == $v['id'])
                    {
                        $v1['children'] = [];
                        $v['children'][] = $v1;
                    }
                }
                $cates[] = $v;
            }
        } 
        // dump($cates);
        $cate = CateModel::getCate(); 

        //首页显示的分类，由于获取不到id，因此采用固定的查询
        $cid= $this->request->get('cid');
        // dump($cid);
        if(isset($cid))
        {
            $pro_list = ProductIndex::where('p_cate_id',$cid)->select();
            // return ['status'=>1,'message'=>'成功'];
            // 返回数据转换为json后不再报错
            json_encode(array('code'=>1,'msg'=>'查询成功'));
        }else{
            // return ['status'=>1,'message'=>'成功'];
            $pro_list = ProductIndex::where('p_cate_id',3)->limit(4)->select();
            $pro_list2 = ProductIndex::where('p_cate_id',4)->limit(4)->select();

            // return ['status'=>1,'message'=>'成功'];
            json_encode(array('code'=>0,'msg'=>'查询失败'));

        }
        // dump($pro_list);
        // $pro_list2 = ProductIndex::where('p_cate_id',4)->select();
        //轮播图
        //获取最新的三条数据
        // 设置不查询分类为设计师的产品
        $map['p_cate_id'] = array('neq',8);
        $last_pro = ProductIndex::where($map)->order('id', 'desc')->limit(3)->select();
        // dump($last_pro);
        // $sec_cate[] = $last_pro['p_cate_id'];
      
        //查询设计师
        $designer = ProductIndex::where('p_cate_id',8)->limit(3)->select();
        // dump($designer);
        $this->view->assign('designer',$designer);
        $this->view->assign('last_pro',$last_pro);
        $this->view->assign('pro_list',$pro_list);
        $this->view->assign('pro_list2',$pro_list2);
        $this->view->assign('cate',$cate);//有层级信息的
        $this->view->assign('cates',$cates);
        return $this->view->fetch('index');
    } 

    public function menu()
    {
        $menu_list = Db::table('cate')->select();
        // dump($menu_list);
        // 二级菜单实现
        $cates = [];
        foreach ($menu_list as $v) {
            if($v['pid'] == 0)
            {
                foreach ($menu_list as $v1) {
                    if($v1['pid'] == $v['id'])
                    {
                        $v1['children'] = [];
                        $v['children'][] = $v1;
                    }
                }
                $cates[] = $v;
            }
        }        
        // dump($cates);
        $cate = CateModel::getCate();
        // $designer = CateIndex::get('');
        $this->view->assign('cate',$cate);//有层级信息的

        $this->view->assign('cates',$cates);

        return $this->view->fetch('menu');

    }

    //显示产品列表界面
    public function grid(Request $request)
    {   
        $menu_list = Db::table('cate')->select();
        // dump($menu_list);
        // 二级菜单实现
        $cates = [];
        foreach ($menu_list as $v) {
            if($v['pid'] == 0)
            {
                foreach ($menu_list as $v1) {
                    if($v1['pid'] == $v['id'])
                    {
                        $v1['children'] = [];
                        $v['children'][] = $v1;
                    }
                }
                $cates[] = $v;
            }
        } 
        // dump($cates);
        // 定义查询条件
        $map = [];

        // 控制页码最小为1，即显示第一页
        $page = max(1,(int)input('get.page'));
        $pageSize = 9;
        $count = ProductIndex::where($map)->count();
            // 获取搜索关键字
        $keywords = $this->request->param('keywords');
        $p_price = $this->request->param('p_price');
        // dump($p_price);
        //获取url传过来的分类id
        $cate_id  = $this->request->param('id');
        // dump($cate_id);
        // 查询是否有子分类
        $child_cate = CateIndex::where('pid',$cate_id)->select();
        // dump($child_cate);
        // 如果有子分类 则查询子分类id
        if(!empty($child_cate))
        {
            foreach ($child_cate as $v) {
            $child_id[] = $v['id'];
            }
            // dump($child_id);
            // 构造子分类查询条件
            $map['p_cate_id'] = array('in',$child_id);   
            $pro_list = ProductIndex::where($map)->paginate($pageSize,$count,['query'=>$this->request->param() ]);
        }     
        else
        {
            // 如果直接是子分类id就根据条件查询
            
            if(isset($cate_id))
            {
                $map['p_cate_id'] = $cate_id;
                $pro_list = ProductIndex::where($map)->paginate($pageSize,$count,['query'=>$this->request->param() ]);
            }
            elseif(isset($keywords)){
                $map['p_name'] = ['like','%'.$keywords.'%'];
                $pro_list = ProductIndex::where($map)->paginate($pageSize,$count,['query'=>$this->request->param() ]);
            }
            else{
                // 否则查询全部
                $map['p_cate_id'] = array('neq',8);
                $pro_list = ProductIndex::where($map)->paginate($pageSize,$count,['query'=>$this->request->param() ]);
            }
        }

        // 获取有层级信息的分类
        $cate = CateModel::getCate();
         
        $this->view->assign('cate',$cate);//有层级信息的
        $this->view->assign('cate_id',$cate_id);           
        $this->view->assign('count',$count);           
        $this->view->assign('page',$page); 
        $this->view->assign('pageSize',$pageSize);                             
        $this->view->assign('cates',$cates);
        $this->view->assign('pro_list',$pro_list);

        return $this->view->fetch('grid');
    }

    public function detail( Request $request)
    {
        $menu_list = Db::table('cate')->select();
        // dump($menu_list);
        // 二级菜单实现
        $cates = [];
        foreach ($menu_list as $v) {
            if($v['pid'] == 0)
            {
                foreach ($menu_list as $v1) {
                    if($v1['pid'] == $v['id'])
                    {
                        $v1['children'] = [];
                        $v['children'][] = $v1;
                    }
                }
                $cates[] = $v;
            }
        }        
        // dump($cates);
        // 传递过来的产品参数id
        $pro_id = $this->request->param('id');
        // dump($pro_id);
        $pro_detail = ProductIndex::where('id',$pro_id)->find();
        // dump($pro_detail);
        //查询所有的分类
        $cate_list = CateIndex::all();

        //查询产品对应的图片
        $pro_imgs = ImageIndex::where('pid',$pro_id)->select();
        // dump($pro_imgs);

        // $carts = CartIndex::all();
        $is_cart = CartIndex::get($pro_id);

        $this->view->assign('is_cart',$is_cart);

        // $this->view->assign('carts',$carts);

        $this->view->assign('pro_imgs',$pro_imgs);
        $this->view->assign('cate_list',$cate_list);
        $this->view->assign('pro_detail',$pro_detail);  
        $this->view->assign('cates',$cates);
        return $this->view->fetch('detail');
    }


   //收藏文章
    public function fav(Request $request){
        //判断是ajax请求
        if(!$this->request->isAjax()){
            return ['status'=>-1,'message'=>'请求类型错误'];
        }
        //
        $data = $this->request->param();
        // halt($data);
        if(empty($data['session_id'])){
            return ['status'=>2,'message'=>'请先登陆再收藏'];
        }

        $map['p_cate_id']=$data['p_cate_id'];
        $map['product_id']=$data['product_id'];

        //查询数据库
        $fav = CartIndex::where($map)->find();
        if(is_null($fav)){

            CartIndex::create([
                'p_cate_id'=>$data['p_cate_id'],
                'product_id'=>$data['product_id']   
            ]);

            return ['status'=>1,'message'=>'加购成功'];
        }

            CartIndex::where($map)->delete();
            return ['status'=>0,'message'=>'已取消'];

    }

    public function contact()
    {
        $menu_list = Db::table('cate')->select();
        // dump($menu_list);
        // 二级菜单实现
        $cates = [];
        foreach ($menu_list as $v) {
            if($v['pid'] == 0)
            {
                foreach ($menu_list as $v1) {
                    if($v1['pid'] == $v['id'])
                    {
                        $v1['children'] = [];
                        $v['children'][] = $v1;
                    }
                }
                $cates[] = $v;
            }
        } 
        $this->view->assign('cates',$cates);

        return $this->view->fetch('contact');
    }    

    public function comment(Request $request)
    {
        $data = $this->request->param();
        dump($data);
        $res = ContactIndex::create($data);
        if(isset($res))
        {
            return ['status'=>1,'message'=>'邮件发表成功'];
        }else
        {
            return ['status'=>0,'message'=>'发表失败'];
        }
    }
    

}
