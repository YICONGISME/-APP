<?php
namespace app\index\model;
use think\Model;
use think\Collection;
class Cart extends Model
{
}