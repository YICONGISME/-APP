<?php
namespace app\index\model;
use think\Model;
use think\Collection;
class Slide extends Model
{
}