<?php
namespace app\index\model;
use think\Model;
use think\Collection;
class Cate extends Model
{
//后期优化用
	public static function getCate()
	{
		$menu_list = self::select();
        // dump($menu_list);
        // 二级菜单实现
        $cates = [];
        foreach ($menu_list as $v) {
            if($v['pid'] == 0)
            {
                foreach ($menu_list as $v1) {
                    if($v1['pid'] == $v['id'])
                    {
                        $v1['children'] = [];
                        $v['children'][] = $v1;
                    }
                }
                $cates[] = $v;
            }
        }
		return Collection::make($cates)->toArray();

	}
}


?>