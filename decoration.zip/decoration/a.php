<?php
无限菜单实现方法
/*------------------第二种---------------*/

$menu_list = Db::table('cate')->select();
// dump($menu_list);
$cates = [];
foreach ($menu_list as $v) {
    if($v['pid'] == 0)
    {
        //二级
        foreach ($menu_list as $v1) {
            if($v1['pid'] == $v['id'])
            {
                $v1['children'] = [];
                $v['children'][] = $v1;
                //三级
                foreach($menu_list as $v2)
                {
                    if($v2['pid'] == $v1['id'])
                    {
                        $v1->children[] = $v2;
                    }
                }
            }
        }
        $cates[] = $v;
    }
}
dump($cates);
/*
array(2) {
  [0] => array(5) {
    ["id"] => int(1)
    ["pid"] => int(0)
    ["cate_name"] => string(9) "分类一"
    ["cate_order"] => int(1)
    ["children"] => array(2) {
      [0] => array(5) {
        ["id"] => int(3)
        ["pid"] => int(1)
        ["cate_name"] => string(12) "子分类一"
        ["cate_order"] => int(1)
        ["children"] => array(0) {
        }
      }
      [1] => array(5) {
        ["id"] => int(5)
        ["pid"] => int(1)
        ["cate_name"] => string(12) "子分类二"
        ["cate_order"] => int(3)
        ["children"] => array(0) {
        }
      }
    }
  }
*/
$this->view->assign('cates',$cates);
return $this->view->fetch('index');

<html>
{foreach name="$cates" id="vo"}
    <li class="dropdown">
        <a href="index.php"><img src="__STATIC__/assets/images/menu-icon1.png" alt="menu-icon1" /> {$vo.cate_name} <i class="fa fa-angle-right" aria-hidden="true"></i></a>
        <ul class="dropdown-menu right">
            {foreach name="$vo['children']" id="vo1"}
            <li><a href="grid.php">{$vo1.cate_name}</a></li>
            {/foreach}
        </ul>
    </li>
{/foreach}
</html>



/*------------------第二种---------------*/
$menu_list = Db::table('cate')->select();
// dump($menu_list);

$cates = $this->gettreeitems($menu_list);
dump($cates);
$this->view->assign('cates',$cates);
return $this->view->fetch('index');

//菜单呈现树形结构
private function gettreeitems($items)
{
    $tree = array();
    foreach ($items as $item) {
        if(isset($items[$item['pid']])){
            $items[$item['pid']]['children'][] = &$items[$item['id']];
        }else
        {
            $tree[] = &$items[$item['id']];
        }
    }
    return $tree;
}

{volist name="$cates" id="vo"}
<li class="dropdown">
    <a href="index.php"><img src="__STATIC__/assets/images/menu-icon1.png" alt="menu-icon1" /> {$vo.cate_name} <i class="fa fa-angle-right" aria-hidden="true"></i></a>
    <ul class="dropdown-menu right">
        {volist name="$vo['children']" id="vo1"}
        <li><a href="grid.php">{$vo1.cate_name}</a></li>
        {/volist}
    </ul>
</li>
{/volist}



/*------------------第三种---------------*/

$menu_list = Db::table('cate')->select();
$menu1 = array();
$menu2 = array();

foreach ($menu_list as $key => $value) {
    $menu_list[$key]['child'] = array();
    $menu1 = CateModel::where("pid=".$value['id'])->select();

    foreach($cate1 as $k => $v)
    {
        array_push($menu_list[$key]['child'],$v);
        $menu_list['child']['$k']['child2'] = array();

        $menu2 = CateModel::where("pid=".$v['id'])->select();
        foreach ($menu2 as $v2) {

            array_push($menu_list[$key]['child'][$k]['child2'],$v);
        }
    }
}

?>